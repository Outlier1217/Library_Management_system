<?php
include "config.php";


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();

// Handle Profile Update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Handle Image Upload
    if (!empty($_FILES["profile_image"]["name"])) {
        $target_dir = "uploads/";
        $image_name = time() . "_" . basename($_FILES["profile_image"]["name"]);
        $target_file = $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
                $conn->query("UPDATE users SET profile_image='$image_name' WHERE id=$user_id");
                $_SESSION['profile_image'] = $image_name;
            } else {
                $error_message = "Error uploading file.";
            }
        } else {
            $error_message = "Invalid file format. Allowed: JPG, PNG, GIF.";
        }
    }

    // Update Name & Email
    $stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
    $stmt->bind_param("ssi", $name, $email, $user_id);
    if ($stmt->execute()) {
        $success_message = "Profile updated successfully!";
    } else {
        $error_message = "Error updating profile.";
    }
}

// Handle Password Change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];

    if (password_verify($current_password, $user['password'])) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET password='$hashed_password' WHERE id=$user_id");
        $success_message = "Password updated successfully!";
    } else {
        $error_message = "Current password is incorrect!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<style>

/* Profile Page */
.profile-container {
    width: 400px;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
    text-align: center;
    margin: auto;
    margin-top: 50px;
    animation: fadeIn 0.5s ease-in-out;
}

.profile-container h2 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #333;
}

/* Success & Error Messages */
.success-msg, .error-msg {
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 10px;
    font-size: 14px;
}

.success-msg {
    background: rgba(0, 255, 0, 0.1);
    color: green;
}

.error-msg {
    background: rgba(255, 0, 0, 0.1);
    color: red;
}

/* Profile Info */
.profile-info {
    text-align: left;
}

.profile-img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    display: block;
    margin: auto;
    margin-bottom: 10px;
}

.input-group {
    margin-bottom: 15px;
    text-align: left;
}

.input-group label {
    font-size: 14px;
    color: grey;
    display: block;
}

.input-group input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    transition: 0.3s;
}

.input-group input:focus {
    border-color: orange;
    outline: none;
}

/* Profile Button */
.profile-btn {
    background: orange;
    color: white;
    border: none;
    width: 100%;
    padding: 12px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

.profile-btn:hover {
    background: darkorange;
}

/* Responsive */
@media screen and (max-width: 500px) {
    .profile-container {
        width: 90%;
    }
}


</style>
<body>
    <div class="profile-container">
        <h2>My Profile</h2>

        <?php if (isset($success_message)) : ?>
            <p class="success-msg"><?= $success_message; ?></p>
        <?php endif; ?>
        <?php if (isset($error_message)) : ?>
            <p class="error-msg"><?= $error_message; ?></p>
        <?php endif; ?>

        <div class="profile-info">
            <img src="uploads/<?= $user['profile_image']; ?>" alt="Profile Picture" class="profile-img">
            <form action="profile.php" method="POST" enctype="multipart/form-data">
                <div class="input-group">
                    <label>Update Profile Picture:</label>
                    <input type="file" name="profile_image">
                </div>
                <div class="input-group">
                    <label>Full Name:</label>
                    <input type="text" name="name" value="<?= $user['name']; ?>" required>
                </div>
                <div class="input-group">
                    <label>Email Address:</label>
                    <input type="email" name="email" value="<?= $user['email']; ?>" required>
                </div>
                <button type="submit" class="profile-btn">Update Profile</button>
            </form>

            <h3>Change Password</h3>
            <form action="profile.php" method="POST">
                <div class="input-group">
                    <label>Current Password:</label>
                    <input type="password" name="current_password" required>
                </div>
                <div class="input-group">
                    <label>New Password:</label>
                    <input type="password" name="new_password" required>
                </div>
                <button type="submit" name="change_password" class="profile-btn">Update Password</button>
            </form>
        </div>
    </div>
</body>
</html>
