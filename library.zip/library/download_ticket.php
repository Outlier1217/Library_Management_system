<?php
require('libs/fpdf.php');
require('phpqrcode/phpqrcode.php');
include "config.php";

if (!isset($_GET['booking_id'])) {
    die("Invalid request!");
}

$booking_id = (int)$_GET['booking_id']; // Cast to integer for security

// Fetch booking details
$booking = $conn->query("
    SELECT b.*, u.name, u.email, s.seat_number 
    FROM bookings b 
    JOIN users u ON b.user_id = u.id
    JOIN seats s ON b.seat_id = s.id
    WHERE b.id = $booking_id AND b.status = 'confirmed'
")->fetch_assoc();

if (!$booking) {
    die("No confirmed booking found for this ID!");
}

// Convert date format to DD-MM-YYYY
$formatted_start_date = date("d-m-Y", strtotime($booking['start_date']));
$formatted_expiry_date = date("d-m-Y", strtotime($booking['expiry_date']));

// Generate QR Code Data
$qrData = "Name: {$booking['name']}\nEmail: {$booking['email']}\nSeat No: {$booking['seat_number']}\nPlan: ₹{$booking['amount_paid']}\nBooked On: {$formatted_start_date}\nExpiry: {$formatted_expiry_date}"; // Changed total_amount to amount_paid

// Define QR Code Path
$qrCodePath = "uploads/qrcodes/ticket_{$booking['id']}.png";
QRcode::png($qrData, $qrCodePath, QR_ECLEVEL_L, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Your Ticket - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #fff;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #444);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .ticket-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 16px;
            box-shadow: var(--shadow);
            max-width: 400px;
            width: 100%;
            text-align: center;
            color: #333;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.5s ease-in-out;
        }

        .ticket-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 152, 0, 0.1) 0%, transparent 70%);
            transform: rotate(30deg);
            z-index: -1;
        }

        h2 {
            font-size: 26px;
            color: var(--primary-color);
            margin-bottom: 20px;
            font-weight: 600;
        }

        .ticket-details {
            background: #fff3e0;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .ticket-details p {
            font-size: 16px;
            margin: 10px 0;
            color: #555;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .ticket-details p strong {
            color: #333;
            font-weight: 500;
        }

        .qr-code {
            margin-top: 20px;
            max-width: 150px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .download-btn {
            display: inline-block;
            padding: 12px 25px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .download-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 152, 0, 0.4);
        }

        .download-btn i {
            margin-right: 8px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .ticket-container {
                padding: 25px;
                max-width: 100%;
            }

            h2 {
                font-size: 22px;
            }

            .ticket-details p {
                font-size: 14px;
                flex-direction: column;
                text-align: left;
            }

            .qr-code {
                max-width: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="ticket-container">
        <h2><i class="fa-solid fa-ticket-alt"></i> Your Booking Ticket</h2>
        <div class="ticket-details">
            <p><strong>Name:</strong> <span><?= htmlspecialchars($booking['name']); ?></span></p>
            <p><strong>Email:</strong> <span><?= htmlspecialchars($booking['email']); ?></span></p>
            <p><strong>Seat No:</strong> <span><?= htmlspecialchars($booking['seat_number']); ?></span></p>
            <p><strong>Plan:</strong> <span>₹<?= htmlspecialchars($booking['amount_paid']); ?>/month</span></p>
            <p><strong>Booked On:</strong> <span><?= htmlspecialchars($formatted_start_date); ?></span></p>
            <p><strong>Expiry:</strong> <span><?= htmlspecialchars($formatted_expiry_date); ?></span></p>
            <img src="<?= htmlspecialchars($qrCodePath); ?>" alt="QR Code" class="qr-code">
        </div>
        <a href="download_ticket_pdf.php?booking_id=<?= htmlspecialchars($booking['id']); ?>" class="download-btn">
            <i class="fa-solid fa-download"></i> Download PDF
        </a>
    </div>
</body>
</html>