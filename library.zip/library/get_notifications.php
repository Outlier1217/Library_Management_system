<?php
include "config.php";
header('Content-Type: application/json');

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT id, message FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = [
        'id' => $row['id'],
        'message' => htmlspecialchars($row['message'])
    ];
}
echo json_encode($notifications);
?>