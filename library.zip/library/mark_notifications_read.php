<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    echo "error";
    exit();
}

$user_id = $_SESSION['user_id'];

// Mark all notifications as read
$conn->query("UPDATE notifications SET is_read = 1 WHERE user_id = $user_id OR user_id IS NULL");

echo "success";
?>
