<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$seat_id = $_POST['seat_id'] ?? null;
$plan_cost = $_POST['plan'] ?? null;
$voucher_code = $_POST['voucher_code'] ?? null;

// Validate input
if (!$seat_id || !$plan_cost) {
    die("Error: Invalid seat selection or plan.");
}

// Check if the seat is already booked or reserved
$seat_check = $conn->query("SELECT status FROM seats WHERE id = $seat_id");
if ($seat_check->num_rows > 0) {
    $seat = $seat_check->fetch_assoc();
    if ($seat['status'] === 'booked' || $seat['status'] === 'reserved') {
        echo "<script>alert('This seat is already taken! Please select another seat.'); window.location.href='booking.php?reserve=1';</script>";
        exit();
    }
}

// Fetch user credits
$user_query = $conn->query("SELECT credits FROM users WHERE id = $user_id");
if (!$user_query || $user_query->num_rows == 0) {
    die("Error: User not found.");
}

$user = $user_query->fetch_assoc();
$credits = (int)$user['credits'];

// Calculate reservation cost (1/4 of plan cost, rounded)
$reservation_cost = round($plan_cost / 4);

// Apply voucher (if applicable)
$discount = 0;
if (!empty($voucher_code)) {
    $voucher_query = $conn->query("SELECT credit_value FROM vouchers WHERE code = '$voucher_code' AND is_used = 0");
    if ($voucher_query->num_rows > 0) {
        $voucher = $voucher_query->fetch_assoc();
        $discount = (int)$voucher['credit_value'];
        $reservation_cost -= $discount;
        $conn->query("UPDATE vouchers SET is_used = 1 WHERE code = '$voucher_code'");
    }
}

// Ensure the final cost isn't negative
$reservation_cost = max(0, $reservation_cost);

// Check if user has enough credits
if ($credits < $reservation_cost) {
    echo "<script>alert('Insufficient LM Credits. Please recharge.'); window.location.href='booking.php?reserve=1';</script>";
    exit();
}

// Start transaction
$conn->begin_transaction();

try {
    // Deduct credits
    $new_credits = $credits - $reservation_cost;
    $conn->query("UPDATE users SET credits = $new_credits WHERE id = $user_id");

    // Calculate dates
    $start_date = date('Y-m-d');
    $end_date = date('Y-m-d', strtotime('+30 days'));

    // Insert reservation
    $stmt = $conn->prepare("INSERT INTO bookings (user_id, seat_id, amount_paid, total_amount, status, start_date, expiry_date) VALUES (?, ?, ?, ?, 'reserved', ?, ?)");
    $stmt->bind_param("iiiiss", $user_id, $seat_id, $reservation_cost, $plan_cost, $start_date, $end_date);
    $stmt->execute();

    // Update seat status
    $conn->query("UPDATE seats SET status = 'reserved' WHERE id = $seat_id");

    // Commit transaction
    $conn->commit();

    echo "<script>alert('Seat reserved successfully! Pay the remaining amount to confirm your booking.'); window.location.href='dashboard.php';</script>";
} catch (Exception $e) {
    $conn->rollback();
    error_log("Reservation failed: " . $e->getMessage());
    die("Error: Reservation failed. Please try again.");
}
?>