<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch latest booking details
$booking = $conn->query("SELECT b.*, u.name, s.seat_number FROM bookings b 
                         JOIN users u ON b.user_id = u.id
                         JOIN seats s ON b.seat_id = s.id
                         WHERE b.user_id=$user_id ORDER BY b.id DESC LIMIT 1")->fetch_assoc();

if (!$booking) {
    die("No booking found!");
}

$formatted_start_date = date("d-m-Y", strtotime($booking['start_date']));
$formatted_end_date = date("d-m-Y", strtotime($booking['end_date']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation - LM Library</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #222, #555);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .confirmation-container {
            width: 90%;
            max-width: 450px;
            background: rgba(255, 255, 255, 0.2);
            padding: 25px;
            border-radius: 12px;
            backdrop-filter: blur(10px);
            box-shadow: 0px 4px 10px rgba(255, 255, 255, 0.1);
            text-align: center;
            color: white;
        }
        h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .details {
            text-align: left;
            margin-top: 15px;
        }
        .details p {
            font-size: 16px;
            margin: 8px 0;
        }
        .slide-btn {
            width: 100%;
            margin-top: 20px;
            padding: 15px;
            font-size: 18px;
            font-weight: bold;
            color: white;
            background: orange;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
        }
        .slide-btn:hover {
            background: darkorange;
        }
    </style>
</head>
<body>

<div class="confirmation-container">
    <h2>🎟️ LM Library</h2>
    <p><strong>Booking Confirmation</strong></p>
    
    <div class="details">
        <p><strong>Name:</strong> <?= $booking['name']; ?></p>
        <p><strong>Seat No:</strong> <?= $booking['seat_number']; ?></p>
        <p><strong>Plan:</strong> ₹<?= $booking['subscription_plan']; ?>/month</p>
        <p><strong>Booked On:</strong> <?= $formatted_start_date; ?></p>
        <p><strong>Expiry:</strong> <?= $formatted_end_date; ?></p>
    </div>

    <form id="paymentForm" method="post" action="payment.php">
    <input type="hidden" name="seat_id" value="<?= $booking['seat_id']; ?>">
    <input type="hidden" name="plan" value="<?= $booking['subscription_plan']; ?>">
</form>

<button class="slide-btn" onclick="document.getElementById('paymentForm').submit();">
    Slide to Pay ➡
</button>



</div>

</body>
</html>
