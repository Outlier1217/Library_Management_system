<?php
include "config.php";

if (!isset($_SESSION['user_id']) || !isset($_GET['seat_id']) || !isset($_GET['plan'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$seat_id = $_GET['seat_id'];
$plan = $_GET['plan'];

// Get user credits
$user = $conn->query("SELECT credits FROM users WHERE id = $user_id")->fetch_assoc();
$lm_credits = $user['credits'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        .container { max-width: 400px; margin: auto; padding: 20px; border-radius: 10px; background: #f4f4f4; }
        .pay-btn { background: orange; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .pay-btn:hover { background: darkorange; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Confirm Payment</h2>
        <p><strong>Your Credits:</strong> <?= $lm_credits; ?> LM</p>
        <p><strong>Seat Number:</strong> <?= $seat_id; ?></p>
        <p><strong>Plan Cost:</strong> ₹<?= $plan; ?></p>

        <?php if ($lm_credits >= $plan): ?>
            <form action="confirm_payment.php" method="POST">
                <input type="hidden" name="seat_id" value="<?= $seat_id; ?>">
                <input type="hidden" name="plan" value="<?= $plan; ?>">
                <button type="submit" class="pay-btn">Slide to Pay</button>
            </form>
        <?php else: ?>
            <p style="color: red;">Insufficient credits. Please recharge.</p>
        <?php endif; ?>
    </div>
</body>
</html>
