<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $voucher_code = $_POST['voucher_code'];

    $voucher = $conn->query("SELECT * FROM vouchers WHERE code='$voucher_code' AND used=0")->fetch_assoc();

    if ($voucher) {
        $credit_value = $voucher['credit_value'];
        
        // Update user's credits
        $conn->query("UPDATE users SET credits = credits + $credit_value WHERE id = $user_id");

        // Mark voucher as used
        $conn->query("UPDATE vouchers SET used=1 WHERE code='$voucher_code'");

        echo "<script>alert('Voucher redeemed! Credits added: $credit_value'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Invalid or used voucher!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Redeem Voucher</title>
</head>
<body>
    <h2>Redeem Voucher</h2>
    <form method="post">
        <label for="voucher_code">Enter Voucher Code:</label>
        <input type="text" name="voucher_code" required>
        <button type="submit">Redeem</button>
    </form>
</body>
</html>
