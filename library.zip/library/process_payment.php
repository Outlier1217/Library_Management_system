<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    echo "login_required";
    exit();
}

$user_id = $_SESSION['user_id'];
$booking_id = $_POST['booking_id'] ?? null;
$amount = (int)$_POST['amount'] ?? 0;

if (!$booking_id || $amount <= 0) {
    echo "invalid_input";
    exit();
}

// Fetch reservation and user credits
$reservation = $conn->query("
    SELECT b.*, s.seat_number 
    FROM bookings b 
    JOIN seats s ON b.seat_id = s.id 
    WHERE b.id = $booking_id AND b.user_id = $user_id AND b.status = 'reserved'
")->fetch_assoc();

$user = $conn->query("SELECT credits FROM users WHERE id = $user_id")->fetch_assoc();
$credits = (int)$user['credits'];

if (!$reservation) {
    echo "no_reservation";
    exit();
}

$remaining_amount = $reservation['total_amount'] - $reservation['amount_paid'];
if ($remaining_amount != $amount) {
    echo "amount_mismatch";
    exit();
}

if ($credits < $remaining_amount) {
    echo "insufficient_credits";
    exit();
}

// Start transaction
$conn->begin_transaction();

try {
    // Deduct remaining amount from credits
    $new_credits = $credits - $remaining_amount;
    $conn->query("UPDATE users SET credits = $new_credits WHERE id = $user_id");

    // Update booking status and total paid amount
    $total_paid = $reservation['amount_paid'] + $remaining_amount;
    $stmt = $conn->prepare("UPDATE bookings SET status = 'confirmed', amount_paid = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param("iii", $total_paid, $booking_id, $user_id);
    $stmt->execute();

    // Update seat status
    $conn->query("UPDATE seats SET status = 'booked' WHERE id = {$reservation['seat_id']}");

    // Commit transaction
    $conn->commit();

    echo "success";
} catch (Exception $e) {
    $conn->rollback();
    error_log("Payment failed: " . $e->getMessage());
    echo "error: " . $e->getMessage();
}
?>