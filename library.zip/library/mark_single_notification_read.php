<?php
include "config.php";
session_start();

$user_id = $_SESSION['user_id'];
$notification_id = $_GET['id'] ?? '';

if ($notification_id) {
    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND (user_id = ? OR user_id IS NULL)");
    $stmt->bind_param("ii", $notification_id, $user_id);
    $stmt->execute();
}

// Return remaining unread count
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$count = $stmt->get_result()->fetch_assoc()['count'];

echo $count;
?>