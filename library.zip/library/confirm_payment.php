<?php
include "config.php";

if (!isset($_SESSION['user_id']) || !isset($_POST['seat_id']) || !isset($_POST['plan'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$seat_id = $_POST['seat_id'];
$final_price = $_POST['plan'];

// Get user credits
$user = $conn->query("SELECT credits FROM users WHERE id = $user_id")->fetch_assoc();
$lm_credits = $user['credits'];

if ($lm_credits < $final_price) {
    die("Insufficient credits. Please recharge.");
}

// Deduct credits
$conn->query("UPDATE users SET credits = credits - $final_price WHERE id = $user_id");

// Confirm the booking
$conn->query("UPDATE bookings SET status = 'confirmed' WHERE user_id = $user_id AND seat_id = $seat_id");

// Mark seat as booked
$conn->query("UPDATE seats SET status = 'booked' WHERE id = $seat_id");

// Redirect to invoice page
header("Location: invoice.php?seat_id=$seat_id");
exit();
?>
