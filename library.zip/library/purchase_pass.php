<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_extend = isset($_GET['extend']) && $_GET['extend'] == 1;
$message = '';

// Fetch user credits
$stmt = $conn->prepare("SELECT credits FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$credits = round($user['credits']);

// Fetch existing pass (for extension check)
$stmt = $conn->prepare("SELECT expiry_date FROM library_passes WHERE user_id = ? AND status = 'active' LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$existing_pass = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = $_POST['payment_method'];
    $pass_cost = 500; // 500 INR or 500 LM Credits

    if ($payment_method === 'credits' && $credits >= $pass_cost) {
        // Deduct credits
        $stmt = $conn->prepare("UPDATE users SET credits = credits - ? WHERE id = ?");
        $stmt->bind_param("di", $pass_cost, $user_id);
        $stmt->execute();

        // Log credit history
        $description = $is_extend ? "Extended Library Pass" : "Purchased Library Pass";
        $conn->query("INSERT INTO credit_history (user_id, amount, source, description) VALUES ($user_id, -$pass_cost, 'pass_purchase', '$description')");
    } elseif ($payment_method !== 'cash') {
        $message = "<p class='error'>Insufficient credits or invalid payment method.</p>";
        goto render_page;
    }

    // Calculate dates
    $purchase_date = date('Y-m-d');
    $expiry_date = $is_extend && $existing_pass ? date('Y-m-d', strtotime($existing_pass['expiry_date'] . ' +30 days')) : date('Y-m-d', strtotime('+30 days'));

    // Insert or update pass
    if ($is_extend && $existing_pass) {
        $stmt = $conn->prepare("UPDATE library_passes SET purchase_date = ?, expiry_date = ?, status = 'active' WHERE user_id = ? AND status = 'active'");
        $stmt->bind_param("ssi", $purchase_date, $expiry_date, $user_id);
    } else {
        $stmt = $conn->prepare("INSERT INTO library_passes (user_id, purchase_date, expiry_date) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $user_id, $purchase_date, $expiry_date);
    }

    if ($stmt->execute()) {
        header("Location: library_pass.php");
        exit();
    } else {
        $message = "<p class='error'>Error purchasing pass. Please try again.</p>";
    }
}

render_page:
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $is_extend ? 'Extend Library Pass' : 'Purchase Library Pass'; ?> - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .purchase-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .purchase-container h2 {
            color: #ff9800;
            margin-bottom: 20px;
        }

        .purchase-container p {
            font-size: 16px;
            color: #333;
            margin-bottom: 15px;
        }

        .purchase-container form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .purchase-container label {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            background: #fff3e0;
            border-radius: 8px;
            cursor: pointer;
        }

        .purchase-container input[type="radio"] {
            margin-right: 10px;
        }

        .purchase-container button {
            padding: 10px;
            background: #ff9800;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .purchase-container button:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        .purchase-container .error {
            color: #e74c3c;
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #ff9800;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="purchase-container">
        <h2><?php echo $is_extend ? 'Extend Library Pass' : 'Purchase Library Pass'; ?></h2>
        <p>Price: ₹500 (or 500 LM Credits)</p>
        <p>Your Credits: <?= $credits; ?> LM</p>
        <?= $message; ?>
        <form method="POST">
            <label><input type="radio" name="payment_method" value="cash" required> Pay with Cash (₹500)</label>
            <label><input type="radio" name="payment_method" value="credits" <?php echo $credits < 500 ? 'disabled' : ''; ?>> Pay with LM Credits (500 LM)</label>
            <button type="submit"><?php echo $is_extend ? 'Extend Pass' : 'Purchase Pass'; ?></button>
        </form>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>
</body>
</html>