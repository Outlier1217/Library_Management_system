<?php
require('libs/fpdf.php');
require('phpqrcode/phpqrcode.php');
include "config.php";

if (!isset($_GET['booking_id'])) {
    die("Invalid request!");
}

$booking_id = (int)$_GET['booking_id']; // Cast to integer for security

// Fetch booking details with prepared statement
$stmt = $conn->prepare("
    SELECT b.*, u.name, u.email, s.seat_number 
    FROM bookings b 
    JOIN users u ON b.user_id = u.id
    JOIN seats s ON b.seat_id = s.id
    WHERE b.id = ? AND b.status = 'confirmed'
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();

if (!$booking) {
    die("No confirmed booking found for this ID!");
}

// Convert date format to DD-MM-YYYY
$formatted_start_date = date("d-m-Y", strtotime($booking['start_date']));
$formatted_expiry_date = date("d-m-Y", strtotime($booking['expiry_date'])); // Changed end_date to expiry_date

// Generate QR Code Data
$qrData = "Name: {$booking['name']}\nEmail: {$booking['email']}\nSeat No: {$booking['seat_number']}\nPlan: ₹{$booking['amount_paid']}\nBooked On: {$formatted_start_date}\nExpiry: {$formatted_expiry_date}"; // Changed subscription_plan to amount_paid

// Define QR Code Path
$qrCodePath = "uploads/qrcodes/ticket_{$booking['id']}.png";
QRcode::png($qrData, $qrCodePath, QR_ECLEVEL_L, 5);

// Create PDF Ticket
class TicketPDF extends FPDF {
    function Header() {
        // Add Library Logo (if available)
        if (file_exists('images/library.png')) {
            $this->Image('images/library.png', 10, 10, 30);
        }

        // Title
        $this->SetFont('Arial', 'B', 18);
        $this->SetTextColor(255, 152, 0); // Orange (#ff9800)
        $this->Cell(0, 10, 'LM Library - Booking Ticket', 0, 1, 'C');
        $this->Ln(5);

        // Subtitle
        $this->SetFont('Arial', '', 12);
        $this->SetTextColor(80, 80, 80); // Dark gray
        $this->Cell(0, 10, 'Your Seat Booking Confirmation', 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 10);
        $this->SetTextColor(120, 120, 120); // Light gray
        $this->Cell(0, 10, 'Please present this ticket for verification at LM Library.', 0, 0, 'C');
    }
}

$pdf = new TicketPDF();
$pdf->AddPage();

// Ticket Details Section
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetTextColor(44, 62, 80); // Dark teal (#2c3e50)
$pdf->Cell(0, 8, 'Booking Details', 0, 1);
$pdf->Ln(5);

// Details
$pdf->SetFont('Arial', '', 12);
$pdf->SetTextColor(85, 85, 85); // Medium gray (#555)
$details = [
    "Name" => $booking['name'],
    "Email" => $booking['email'],
    "Seat No" => $booking['seat_number'],
    "Plan" => "₹{$booking['amount_paid']}/month",
    "Booked On" => $formatted_start_date,
    "Expiry" => $formatted_expiry_date
];

$y = $pdf->GetY();
foreach ($details as $key => $value) {
    $pdf->SetX(20);
    $pdf->Cell(50, 10, "$key:", 0, 0, 'L');
    $pdf->Cell(0, 10, htmlspecialchars($value), 0, 1, 'L');
}

// Add QR Code
if (file_exists($qrCodePath)) {
    $pdf->Image($qrCodePath, 80, $y + 60, 50, 50); // Larger QR code, centered
}

// Output PDF for Download
$pdf->Output("D", "Ticket_{$booking['seat_number']}.pdf");

// Clean up QR code file
if (file_exists($qrCodePath)) {
    unlink($qrCodePath);
}

exit();