<?php
include "config.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password, profile_image FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['profile_image'] = $row['profile_image'];
            header("Location: dashboard.php");
        } else {
            $error_message = "Invalid email or password!";
        }
    } else {
        $error_message = "No user found!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<style>

    /* Full-Screen Background */
body {
    font-family: 'Poppins', sans-serif;
    background: url('../img/login-bg.jpg') no-repeat center center/cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

/* Wrapper */
.login-wrapper {
    width: 100%;
    max-width: 400px;
}

/* Login Box */
.login-box {
    background: rgba(255, 255, 255, 0.2);
    padding: 35px;
    border-radius: 15px;
    backdrop-filter: blur(10px);
    box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
    text-align: center;
    animation: fadeIn 0.5s ease-in-out;
    transition: 0.3s;
}

.login-box:hover {
    transform: scale(1.02);
}

/* Title */
.login-box h2 {
    font-size: 26px;
    color: black;
    margin-bottom: 10px;
}

/* Subtitle */
.subtitle {
    font-size: 14px;
    color:rgb(13, 2, 2);
    margin-bottom: 20px;
}

/* Error Message */
.error-msg {
    color: #ff4d4d;
    background: rgba(255, 0, 0, 0.15);
    padding: 10px;
    border-radius: 5px;
    font-size: 14px;
    margin-bottom: 10px;
}

/* Input Group */
.input-group {
    position: relative;
    margin-bottom: 20px;
}

.input-group input {
    width: 100%;
    padding: 12px 10px;
    border: none;
    border-bottom: 2px solid #ff007f;
    background: transparent;
    color: black;
    font-size: 16px;
    outline: none;
    transition: 0.3s;
}

/* Floating Label Effect */
.input-group label {
    position: absolute;
    top: 10px;
    left: 10px;
    font-size: 14px;
    color: rgba(255, 255, 255, 0.6);
    transition: 0.3s;
}

.input-group input:focus ~ label,
.input-group input:valid ~ label {
    top: -10px;
    font-size: 12px;
    color: #ff007f;
}

/* Input Icons */
.input-group i {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255, 255, 255, 0.8);
}

/* Login Button */
.login-btn {
    background: #ff007f;
    color: white;
    border: none;
    width: 100%;
    padding: 12px;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

.login-btn:hover {
    background: #d60069;
    transform: scale(1.05);
}

/* Login Links */
.login-links {
    margin-top: 15px;
    font-size: 14px;
}

.login-links a {
    color: black;
    text-decoration: none;
    font-weight: bold;
    transition: 0.3s;
}

.login-links a:hover {
    text-decoration: underline;
    color:rgb(174, 141, 8);
}

/* Animation */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Responsive */
@media screen and (max-width: 500px) {
    .login-wrapper {
        width: 90%;
    }
}


</style>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Welcome Back</h2>
            <p class="subtitle">Sign in to continue</p>
            <?php if (isset($error_message)) : ?>
                <p class="error-msg"><?= $error_message; ?></p>
            <?php endif; ?>
            <form action="login.php" method="POST">
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit" class="login-btn">Login</button>
            </form>
            <div class="login-links">
                <a href="forgot_password.php">Forgot Password?</a>
                <p>Don't have an account? <a href="register.php">Register here</a></p>
            </div>
        </div>
    </div>
</body>
</html>
