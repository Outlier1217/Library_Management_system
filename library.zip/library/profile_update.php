<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details securely
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = trim($_POST['phone']);
    $home_address = trim($_POST['home_address']);
    $dob = trim($_POST['dob']);
    
    $profile_photo = $user['profile_photo'] ?? 'assets/img/default-avatar.png';
    $id_proof = $user['id_proof'] ?? '';

    // Handle Profile Image Upload
    if (!empty($_FILES["profile_photo"]["name"])) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = mime_content_type($_FILES["profile_photo"]["tmp_name"]);
        if (in_array($file_type, $allowed_types) && $_FILES["profile_photo"]["size"] <= 2 * 1024 * 1024) { // 2MB limit
            $profile_photo = "uploads/" . time() . "_" . basename($_FILES["profile_photo"]["name"]);
            if (!move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $profile_photo)) {
                $error_message = "Failed to upload profile photo.";
            }
        } else {
            $error_message = "Invalid profile photo. Use JPEG, PNG, or GIF (max 2MB).";
        }
    }

    // Handle ID Proof Upload
    if (!empty($_FILES["id_proof"]["name"])) {
        $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
        $file_type = mime_content_type($_FILES["id_proof"]["tmp_name"]);
        if (in_array($file_type, $allowed_types) && $_FILES["id_proof"]["size"] <= 5 * 1024 * 1024) { // 5MB limit
            $id_proof = "uploads/" . time() . "_" . basename($_FILES["id_proof"]["name"]);
            if (!move_uploaded_file($_FILES["id_proof"]["tmp_name"], $id_proof)) {
                $error_message = "Failed to upload ID proof.";
            }
        } else {
            $error_message = "Invalid ID proof. Use JPEG, PNG, or PDF (max 5MB).";
        }
    }

    if (!isset($error_message)) {
        $stmt = $conn->prepare("UPDATE users SET phone = ?, home_address = ?, dob = ?, profile_photo = ?, id_proof = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $phone, $home_address, $dob, $profile_photo, $id_proof, $user_id);
        if ($stmt->execute()) {
            $success_message = "Profile updated successfully! Redirecting...";
            header("Refresh: 2; url=dashboard.php");
        } else {
            $error_message = "Error updating profile: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #fff;
            --shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .profile-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 450px;
            text-align: center;
        }

        h2 {
            font-size: 24px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .success-msg, .error-msg {
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .success-msg {
            background: rgba(76, 175, 80, 0.1);
            color: var(--secondary-color);
        }

        .error-msg {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger-color);
        }

        .profile-pic-container {
            position: relative;
            margin-bottom: 20px;
        }

        .profile-pic-container img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: 3px solid var(--primary-color);
            object-fit: cover;
            transition: var(--transition);
        }

        .profile-pic-container:hover img {
            opacity: 0.8;
        }

        .profile-pic-container label {
            cursor: pointer;
            display: block;
        }

        .profile-pic-container p {
            font-size: 14px;
            color: #333;
            margin-top: 5px;
            transition: var(--transition);
        }

        .profile-pic-container:hover p {
            color: var(--primary-color);
        }

        .profile-pic-container input {
            display: none;
        }

        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .input-group label {
            font-size: 14px;
            color: #333;
            display: block;
            margin-bottom: 5px;
        }

        .input-group input,
        .input-group textarea {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 16px;
            background: #f9f9f9;
            color: #333;
            outline: none;
            transition: var(--transition);
        }

        .input-group input:focus,
        .input-group textarea:focus {
            border-color: var(--primary-color);
            background: #fff;
        }

        .input-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .input-group input::placeholder,
        .input-group textarea::placeholder {
            color: #999;
        }

        .input-group a {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 12px;
        }

        .input-group a:hover {
            text-decoration: underline;
        }

        .profile-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: var(--transition);
        }

        .profile-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
        }

        .back-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .profile-container {
                padding: 20px;
                max-width: 100%;
            }

            .profile-pic-container img {
                width: 80px;
                height: 80px;
            }

            .input-group input,
            .input-group textarea {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h2><i class="fa-solid fa-user-edit"></i> Update Your Profile</h2>

        <?php if (isset($success_message)): ?>
            <p class="success-msg"><?= $success_message; ?></p>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <p class="error-msg"><?= $error_message; ?></p>
        <?php endif; ?>

        <form action="profile_update.php" method="POST" enctype="multipart/form-data">
            <div class="profile-pic-container">
                <label for="profile_photo">
                    <img id="previewImage" src="<?= htmlspecialchars($user['profile_photo'] ?? 'assets/img/default-avatar.png'); ?>" alt="Profile Picture">
                    <p>Change Profile Picture</p>
                </label>
                <input type="file" name="profile_photo" id="profile_photo" accept="image/*">
            </div>

            <div class="input-group">
                <label>Phone Number:</label>
                <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? ''); ?>" required pattern="[0-9]{10}" title="Enter a 10-digit phone number">
            </div>

            <div class="input-group">
                <label>Home Address:</label>
                <textarea name="home_address" required><?= htmlspecialchars($user['home_address'] ?? ''); ?></textarea>
            </div>

            <div class="input-group">
                <label>Date of Birth:</label>
                <input type="date" name="dob" value="<?= htmlspecialchars($user['dob'] ?? ''); ?>" required max="<?= date('Y-m-d'); ?>">
            </div>

            <div class="input-group">
                <label>ID Proof (JPEG/PNG/PDF):</label>
                <input type="file" name="id_proof" accept="image/jpeg,image/png,application/pdf">
                <?php if (!empty($user['id_proof'])): ?>
                    <p>Uploaded: <a href="<?= htmlspecialchars($user['id_proof']); ?>" target="_blank">View ID Proof</a></p>
                <?php endif; ?>
            </div>

            <button type="submit" class="profile-btn">Update Profile</button>
            <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
        </form>
    </div>

    <script>
        function previewFile() {
            const preview = document.getElementById('previewImage');
            const file = document.getElementById('profile_photo').files[0];
            const reader = new FileReader();

            reader.onloadend = function () {
                preview.src = reader.result;
            };

            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>