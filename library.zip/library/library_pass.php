<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check and expire old passes
$current_date = date('Y-m-d');
$conn->query("UPDATE library_passes SET status = 'expired' WHERE expiry_date <= '$current_date' AND status = 'active'");

// Fetch user details
$stmt = $conn->prepare("SELECT name, id FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Fetch active library pass
$stmt = $conn->prepare("SELECT * FROM library_passes WHERE user_id = ? AND status = 'active' ORDER BY purchase_date DESC LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$pass = $stmt->get_result()->fetch_assoc();

// If no active pass, redirect to purchase page
if (!$pass) {
    header("Location: purchase_pass.php");
    exit();
}

// Generate QR Code Data
$qrData = "Name: {$user['name']}\nLM ID: {$user['id']}\nPurchase Date: " . date("d-m-Y", strtotime($pass['purchase_date'])) . "\nExpiry: " . date("d-m-Y", strtotime($pass['expiry_date']));
$qrCodePath = "uploads/qrcodes/pass_{$pass['id']}.png";
require('phpqrcode/phpqrcode.php');
QRcode::png($qrData, $qrCodePath, QR_ECLEVEL_L, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Pass - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .pass-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .pass-container h2 {
            color: #ff9800;
            margin-bottom: 20px;
        }

        .pass-details {
            background: #fff3e0;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .pass-details p {
            margin: 10px 0;
            font-size: 16px;
            color: #333;
        }

        .pass-details img {
            margin-top: 15px;
            max-width: 150px;
        }

        .back-btn, .extend-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #ff9800;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            margin: 5px;
        }

        .back-btn:hover, .extend-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="pass-container">
        <h2>Library Pass</h2>
        <div class="pass-details">
            <p><strong>Name:</strong> <?= htmlspecialchars($user['name']); ?></p>
            <p><strong>LM ID:</strong> <?= $user['id']; ?></p>
            <p><strong>Purchase Date:</strong> <?= date("d-m-Y", strtotime($pass['purchase_date'])); ?></p>
            <p><strong>Expiry Date:</strong> <?= date("d-m-Y", strtotime($pass['expiry_date'])); ?></p>
            <img src="<?= htmlspecialchars($qrCodePath); ?>" alt="QR Code">
        </div>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
        <?php if (strtotime($pass['expiry_date']) < strtotime('+7 days')): ?>
            <a href="purchase_pass.php?extend=1" class="extend-btn">Extend Pass</a>
        <?php endif; ?>
    </div>
</body>
</html>