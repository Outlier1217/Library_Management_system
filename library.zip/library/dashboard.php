<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
if (!$stmt) die("Database error: " . $conn->error);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if (!$result->num_rows) die("User not found.");
$user = $result->fetch_assoc();
$credits = round($user['credits']);

// Fetch unread notifications count
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
if (!$stmt) die("Database error: " . $conn->error);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Fetch all notifications
$notifications = $conn->query("
    SELECT id, message, is_read, created_at 
    FROM notifications 
    WHERE user_id = $user_id OR user_id IS NULL 
    ORDER BY created_at DESC
");

// Fetch subscription expiry date and plan from bookings
$stmt = $conn->prepare("SELECT expiry_date, amount_paid FROM bookings WHERE user_id = ? AND status = 'confirmed' ORDER BY expiry_date DESC LIMIT 1");
if (!$stmt) die("Database error: " . $conn->error);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$subscription = $stmt->get_result()->fetch_assoc();
$expiry_date = $subscription['expiry_date'] ?? null;
$plan_amount = $subscription['amount_paid'] ?? null;

// Fetch active library pass
$stmt = $conn->prepare("SELECT * FROM library_passes WHERE user_id = ? AND status = 'active' ORDER BY purchase_date DESC LIMIT 1");
if (!$stmt) die("Database error: " . $conn->error);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$pass = $stmt->get_result()->fetch_assoc();

// Determine if WhatsApp link should be shown
$show_whatsapp_link = !empty($subscription) || !empty($pass);

// Fetch reservation details
$reservation = $conn->query("
    SELECT b.*, s.seat_number 
    FROM bookings b 
    JOIN seats s ON b.seat_id = s.id 
    WHERE b.user_id = $user_id AND b.status = 'reserved'
")->fetch_assoc();
$has_reservation = !empty($reservation);

// Fetch credit history
$credit_history = $conn->query("
    SELECT amount, source, description, created_at 
    FROM credit_history 
    WHERE user_id = $user_id 
    ORDER BY created_at DESC
");

// Fetch recent activity (last 3 entries from credit_history or bookings)
$recent_activity = $conn->query("
    SELECT 'credit' AS type, amount, description, created_at 
    FROM credit_history 
    WHERE user_id = $user_id 
    UNION 
    SELECT 'booking' AS type, amount_paid AS amount, CONCAT('Booked seat ', s.seat_number) AS description, start_date AS created_at 
    FROM bookings b 
    JOIN seats s ON b.seat_id = s.id 
    WHERE b.user_id = $user_id AND b.status = 'confirmed' 
    ORDER BY created_at DESC 
    LIMIT 3
");

// Subscription message
$subscription_message = '';
if ($expiry_date) {
    $expiry_date_formatted = date("d-m-Y", strtotime($expiry_date));
    $one_week_before = date('Y-m-d', strtotime($expiry_date . ' -7 days'));
    $today = date('Y-m-d');
    if ($today >= $one_week_before) {
        $subscription_message = $credits < 500 
            ? "<p class='warning'>Subscription expires on $expiry_date_formatted. Recharge credits ($credits < 500)!</p>"
            : "<p>Subscription expires on $expiry_date_formatted.</p>";
    } else {
        $subscription_message = "<p>Subscription expires on $expiry_date_formatted.</p>";
    }
} else {
    $subscription_message = "<p class='no-subscription'>No active subscription.</p>";
}

// Plan name for display
$plan_name = $plan_amount ? "₹{$plan_amount}/month Plan" : ($pass ? "Library Pass" : "No Plan");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - LM Library</title>
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #333;
            --shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
            color: var(--text-color);
            min-height: 100vh;
            padding: 20px;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .profile-header {
            background: var(--primary-color);
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-align: center;
            color: white;
            transition: var(--transition);
        }

        .profile-header:hover {
            transform: translateY(-5px);
        }

        .profile-header img {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            border: 4px solid white;
            object-fit: cover;
        }

        .profile-header h2 {
            font-size: 24px;
            margin: 10px 0 5px;
        }

        .plan-info {
            font-size: 14px;
            margin-bottom: 10px;
            color: #fff;
        }

        .library-title {
            font-size: 16px;
            font-weight: 500;
        }

        .logout-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: var(--danger-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .logout-btn:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }

        .whatsapp-link {
            margin-top: 15px;
            display: inline-block;
            padding: 10px 20px;
            background: #25D366;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .whatsapp-link:hover {
            background: #20b354;
            transform: translateY(-2px);
        }

        .user-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            box-shadow: var(--shadow);
        }

        .user-actions div {
            text-align: center;
            font-size: 14px;
            color: var(--text-color);
        }

        .user-actions i {
            font-size: 24px;
            color: var(--primary-color);
            margin-bottom: 8px;
        }

        .user-actions a {
            color: var(--primary-color);
            text-decoration: none;
            transition: var(--transition);
        }

        .user-actions a:hover {
            color: #e68900;
        }

        .notification-badge {
            background: var(--danger-color);
            color: white;
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 50%;
            position: absolute;
            top: -8px;
            right: -8px;
        }

        .notification-container {
            position: relative;
            cursor: pointer;
        }

        .notification-list {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            background: white;
            color: var(--text-color);
            padding: 15px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            min-width: 250px;
            max-width: 90vw;
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            border: 1px solid #ddd;
        }

        .notification-list p {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
            margin: 0;
            font-size: 14px;
            transition: var(--transition);
        }

        .notification-list p:hover {
            background: #f9f9f9;
        }

        .notification-list p:last-child {
            border-bottom: none;
        }

        .notification-list p.read {
            color: #888;
            font-style: italic;
        }

        .subscription-info p {
            text-align: center;
            margin: 20px 0;
            font-size: 15px;
            padding: 10px;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.8);
            box-shadow: var(--shadow);
        }

        .subscription-info .warning {
            color: #c0392b;
            background: rgba(231, 76, 60, 0.1);
        }

        .reservation-section, .credit-history-section, .recent-activity-section {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .reservation-section:hover, .credit-history-section:hover, .recent-activity-section:hover {
            transform: translateY(-5px);
        }

        .reservation-section p {
            font-size: 15px;
            color: var(--text-color);
            margin-bottom: 15px;
        }

        .pay-remaining-btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--secondary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .pay-remaining-btn:hover {
            background: #388e3c;
            transform: translateY(-2px);
        }

        .credit-history-section h3, .recent-activity-section h3 {
            font-size: 20px;
            margin-bottom: 15px;
            color: var(--text-color);
            text-align: center;
        }

        .credit-history-table, .recent-activity-table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            overflow: hidden;
        }

        .credit-history-table th, .credit-history-table td, .recent-activity-table th, .recent-activity-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .credit-history-table th, .recent-activity-table th {
            background: var(--primary-color);
            color: white;
            font-weight: 600;
        }

        .credit-history-table tr:hover, .recent-activity-table tr:hover {
            background: rgba(255, 152, 0, 0.05);
        }

        .credit-history-table td, .recent-activity-table td {
            color: var(--text-color);
            font-size: 14px;
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }

        .card h3 {
            font-size: 18px;
            margin-bottom: 15px;
            color: var(--text-color);
        }

        .card a {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .card a:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        .blank-space {
            height: 40px;
        }

        @media (max-width: 768px) {
            .dashboard-container {
                padding: 10px;
            }

            .profile-header {
                padding: 15px;
            }

            .profile-header img {
                width: 70px;
                height: 70px;
            }

            .user-actions {
                padding: 15px;
            }

            .reservation-section, .credit-history-section, .recent-activity-section {
                padding: 15px;
            }

            .credit-history-table th, .credit-history-table td, .recent-activity-table th, .recent-activity-table td {
                font-size: 12px;
                padding: 8px;
            }

            .notification-list {
                top: 40px;
                left: 0;
                right: 0;
                width: 100%;
                transform: none;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <header class="profile-header">
            <img src="uploads/<?= $user['profile_image'] ?: 'default-avatar.png'; ?>" alt="Profile Picture">
            <h2><?= htmlspecialchars($user['name']); ?></h2>
            <p class="plan-info">LM ID: <?= $user['id']; ?> | <?= $plan_name; ?></p>
            <p class="library-title">LM Library</p>
            <a href="logout.php" class="logout-btn">Logout</a>
            <?php if ($show_whatsapp_link): ?>
                <a href="https://chat.whatsapp.com/K07XaZ2VzWn15QIvSxIAeS" target="_blank" class="whatsapp-link">
                    <i class="fa-brands fa-whatsapp"></i> Join NIMS Group
                </a>
            <?php endif; ?>
            <?php if ($show_whatsapp_link): ?>
                <a href="https://chat.whatsapp.com/Lj8P7fRA4JN3iUjsQqr0q3" target="_blank" class="whatsapp-link">
                    <i class="fa-brands fa-whatsapp"></i> Join Lal Kothi Group
                </a>
            <?php endif; ?>
        </header>

        <!-- User Actions -->
        <div class="user-actions">
            <div>
                <i class="fa-solid fa-pencil"></i>
                <br>
                <a href="profile.php">Edit Profile</a>
            </div>
            <div>
                <i class="fa-solid fa-indian-rupee-sign"></i>
                <br>
                <?= $credits; ?> LM Credits
            </div>
            <div class="notification-container">
                <i class="fa-solid fa-bell notification-btn"></i>
                <br>
                Alert
                <?php if ($unread_count > 0): ?>
                    <span id="notification-badge" class="notification-badge"><?= $unread_count; ?></span>
                <?php endif; ?>
                <div id="notification-list" class="notification-list">
                    <?php while ($notification = $notifications->fetch_assoc()): ?>
                        <p data-notification-id="<?= $notification['id']; ?>" class="<?= $notification['is_read'] ? 'read' : ''; ?>">
                            <?= htmlspecialchars($notification['message']); ?>
                            <small>(<?= date("d-m-Y H:i", strtotime($notification['created_at'])); ?>)</small>
                        </p>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>

        <div class="subscription-info">
            <?= $subscription_message; ?>
        </div>

        <!-- Reservation Section -->
        <?php if ($has_reservation): ?>
            <div class="reservation-section">
                <p>You have a reserved seat (Seat Number: <?= htmlspecialchars($reservation['seat_number']); ?>).</p>
                <a href="pay_remaining.php" class="pay-remaining-btn">Pay Remaining Amount</a>
            </div>
        <?php endif; ?>

        <!-- Credit History Section -->
        <div class="credit-history-section">
            <h3>💰 Credit History</h3>
            <table class="credit-history-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Source</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($credit_history->num_rows > 0): ?>
                        <?php while ($entry = $credit_history->fetch_assoc()): ?>
                            <tr>
                                <td><?= date("d-m-Y H:i", strtotime($entry['created_at'])); ?></td>
                                <td><?= $entry['amount']; ?> LM</td>
                                <td><?= htmlspecialchars(ucfirst($entry['source'])); ?></td>
                                <td><?= htmlspecialchars($entry['description'] ?? 'N/A'); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No credit history available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Recent Activity Section -->
        <div class="recent-activity-section">
            <h3>📋 Recent Activity</h3>
            <table class="recent-activity-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($recent_activity->num_rows > 0): ?>
                        <?php while ($activity = $recent_activity->fetch_assoc()): ?>
                            <tr>
                                <td><?= date("d-m-Y H:i", strtotime($activity['created_at'])); ?></td>
                                <td><?= ucfirst($activity['type']); ?></td>
                                <td><?= $activity['amount']; ?> <?= $activity['type'] === 'credit' ? 'LM' : 'INR'; ?></td>
                                <td><?= htmlspecialchars($activity['description']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No recent activity available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="blank-space"></div>

        <!-- Cards Section -->
        <div class="dashboard-cards">
            
            <div class="card">
                <h3><i class="fa-solid fa-id-card"></i>  Add Info</h3>
                <a href="profile_update.php">Additional Ifno</a>
            </div>
            <div class="card">
                <h3><i class="fa-solid fa-ticket"></i> View Tickets</h3>
                <a href="generate_ticket.php">View Now</a>
            </div>
            <div class="card">
                <h3><i class="fa-solid fa-chair"></i> Book Seat</h3>
                <a href="booking.php">Check Now</a>
            </div>
            <div class="card">
                <h3><i class="fa-solid fa-plus"></i> Add Credits</h3>
                <a href="add_credits.php">Recharge</a>
            </div>
            <div class="card">
                <h3><i class="fa-solid fa-lock"></i> Reserve Seat</h3>
                <a href="booking.php?reserve=1">Reserve Now</a>
            </div>
            <div class="card">
                <h3><i class="fa-solid fa-id-card"></i> Library Pass</h3>
                <a href="library_pass.php">View Pass</a>
            </div>
            <div class="card">
                <h3><i class="fa-solid fa-comment"></i> Suggestion Box</h3>
                <a href="suggestion_box.php">Submit Now</a>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const notificationBtn = document.querySelector(".notification-btn");
            const notificationBadge = document.getElementById("notification-badge");
            const notificationList = document.getElementById("notification-list");
            let unreadCount = <?= $unread_count ?>;

            notificationBtn.addEventListener("click", toggleNotifications);
            document.addEventListener("click", closeNotificationsOutside);

            function toggleNotifications(event) {
                event.stopPropagation();
                const isVisible = notificationList.style.display === "block";
                notificationList.style.display = isVisible ? "none" : "block";

                if (!isVisible && unreadCount > 0) {
                    markAllNotificationsRead();
                }
            }

            function closeNotificationsOutside(event) {
                if (!notificationBtn.contains(event.target) && !notificationList.contains(event.target)) {
                    notificationList.style.display = "none";
                }
            }

            function markAllNotificationsRead() {
                fetch("mark_notification_read.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" }
                })
                .then(response => {
                    if (!response.ok) throw new Error("Network response was not ok");
                    return response.text();
                })
                .then(() => {
                    unreadCount = 0;
                    updateBadge();
                    document.querySelectorAll('#notification-list p:not(.read)').forEach(item => {
                        item.classList.add('read');
                    });
                })
                .catch(error => console.error("Fetch error:", error));
            }

            notificationList.addEventListener("click", function(event) {
                const notificationItem = event.target.closest("p");
                if (notificationItem && notificationItem.dataset.notificationId && !notificationItem.classList.contains("read")) {
                    const notificationId = notificationItem.dataset.notificationId;
                    fetch(`mark_single_notification_read.php?id=${notificationId}`, {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" }
                    })
                    .then(response => {
                        if (!response.ok) throw new Error("Network response was not ok");
                        return response.text();
                    })
                    .then(() => {
                        unreadCount = Math.max(0, unreadCount - 1);
                        updateBadge();
                        notificationItem.classList.add("read");
                    })
                    .catch(error => console.error("Fetch error:", error));
                }
            });

            function updateBadge() {
                notificationBadge.textContent = unreadCount;
                notificationBadge.style.display = unreadCount > 0 ? "inline" : "none";
            }
        });
    </script>
</body>
</html>