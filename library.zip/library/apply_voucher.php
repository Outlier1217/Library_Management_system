<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    echo "You need to log in to apply a voucher.";
    exit();
}

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$user_id = $_SESSION['user_id'];
$voucher_code = $_GET['voucher_code'] ?? '';

if (empty($voucher_code)) {
    echo "No voucher code provided.";
    exit();
}

// Fetch voucher details with prepared statement
$stmt = $conn->prepare("SELECT * FROM vouchers WHERE code = ? AND is_used = 0");
$stmt->bind_param("s", $voucher_code);
$stmt->execute();
$voucher = $stmt->get_result()->fetch_assoc();

if (!$voucher) {
    echo "Invalid or already used voucher.";
    exit();
}

// If voucher is assigned to a user, check if it matches
if ($voucher['assigned_to'] !== NULL && $voucher['assigned_to'] != $user_id) {
    echo "This voucher is not assigned to you.";
    exit();
}

// Apply voucher discount and log in credit history
$credit_value = $voucher['credit_value'];
$conn->begin_transaction();
try {
    // Add credits to user
    $stmt = $conn->prepare("UPDATE users SET credits = credits + ? WHERE id = ?");
    $stmt->bind_param("ii", $credit_value, $user_id);
    $stmt->execute();

    // Log to credit history
    $stmt = $conn->prepare("INSERT INTO credit_history (user_id, amount, source, description) VALUES (?, ?, 'voucher', ?)");
    $description = "Voucher applied: $voucher_code";
    $stmt->bind_param("iis", $user_id, $credit_value, $description);
    $stmt->execute();

    // Mark the voucher as used
    $stmt = $conn->prepare("UPDATE vouchers SET is_used = 1 WHERE id = ?");
    $stmt->bind_param("i", $voucher['id']);
    $stmt->execute();

    $conn->commit();
    echo "Voucher applied successfully! You received $credit_value LM Credits.";
} catch (Exception $e) {
    $conn->rollback();
    echo "Error applying voucher: " . $e->getMessage();
}
?>