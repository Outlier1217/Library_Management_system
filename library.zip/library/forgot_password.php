<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if email exists in users table
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // Generate a unique token
        $token = bin2hex(random_bytes(50));

        // Insert token into password_resets table
        $stmt = $conn->prepare("INSERT INTO password_resets (email, token) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();

        // Create reset link
        $reset_link = "http://lostmonktales.com/reset_password.php?token=" . $token;

        // Send email
        $to = $email;
        $subject = "Password Reset Request";
        $message = "Click the link below to reset your password:\n" . $reset_link;
        $headers = "From: support@lostmonktales.com";

        mail($to, $subject, $message, $headers);

        $success_message = "Password reset link has been sent to your email.";
    } else {
        $error_message = "No account found with that email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* General Styles */
        body {
            font-family: 'Poppins', sans-serif;
            background: url('../img/forgot-password-bg.jpg') no-repeat center center/cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Wrapper */
        .forgot-wrapper {
            width: 100%;
            max-width: 400px;
        }

        /* Forgot Password Box */
        .forgot-box {
            background: rgba(255, 255, 255, 0.2);
            padding: 35px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            animation: fadeIn 0.5s ease-in-out;
            transition: 0.3s;
        }

        .forgot-box:hover {
            transform: scale(1.02);
        }

        /* Title */
        .forgot-box h2 {
            font-size: 26px;
            color: black;
            margin-bottom: 10px;
        }

        /* Subtitle */
        .subtitle {
            font-size: 14px;
            color: rgb(13, 2, 2);
            margin-bottom: 20px;
        }

        /* Success & Error Messages */
        .message {
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .success-msg {
            color: #28a745;
            background: rgba(40, 167, 69, 0.2);
        }

        .error-msg {
            color: #ff4d4d;
            background: rgba(255, 0, 0, 0.15);
        }

        /* Input Group */
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 10px;
            border: none;
            border-bottom: 2px solid #ff007f;
            background: transparent;
            color: black;
            font-size: 16px;
            outline: none;
            transition: 0.3s;
        }

        /* Floating Label Effect */
        .input-group label {
            position: absolute;
            top: 10px;
            left: 10px;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.6);
            transition: 0.3s;
        }

        .input-group input:focus ~ label,
        .input-group input:valid ~ label {
            top: -10px;
            font-size: 12px;
            color: #ff007f;
        }

        /* Input Icons */
        .input-group i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.8);
        }

        /* Reset Button */
        .reset-btn {
            background: #ff007f;
            color: white;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .reset-btn:hover {
            background: #d60069;
            transform: scale(1.05);
        }

        /* Login Links */
        .forgot-links {
            margin-top: 15px;
            font-size: 14px;
        }

        .forgot-links a {
            color: black;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .forgot-links a:hover {
            text-decoration: underline;
            color: rgb(174, 141, 8);
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media screen and (max-width: 500px) {
            .forgot-wrapper {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="forgot-wrapper">
        <div class="forgot-box">
            <h2>Forgot Password</h2>
            <p class="subtitle">Enter your email to receive a reset link</p>
            <?php if (isset($success_message)) : ?>
                <p class="message success-msg"><?= $success_message; ?></p>
            <?php endif; ?>
            <?php if (isset($error_message)) : ?>
                <p class="message error-msg"><?= $error_message; ?></p>
            <?php endif; ?>
            <form action="" method="POST">
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" required placeholder="Email Address">
                </div>
                <button type="submit" class="reset-btn">Send Reset Link</button>
            </form>
            <div class="forgot-links">
                <a href="login.php">Back to Login</a>
            </div>
        </div>
    </div>
</body>
</html>
