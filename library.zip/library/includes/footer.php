<footer class="footer">
    <div class="footer-container">
        <!-- Library Info -->
        <div class="footer-about">
            
        </div>

        <!-- Quick Links -->
        <div class="footer-links">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="index.php">🏠 Home</a></li>
                <li><a href="about.php">ℹ️ About Us</a></li>
                <li><a href="contact.php">📞 Contact Us</a></li>
                <li><a href="booking.php">⚡ Quick Booking</a></li>
            </ul>
        </div>

        <!-- Social Media -->
        <div class="footer-social">
            <h3>Follow Us</h3>
            <a href="#"><img src="fb.png" alt="Facebook"></a>
            <a href="#"><img src="assets/icons/twitter.svg" alt="Twitter"></a>
            <a href="#"><img src="assets/icons/instagram.svg" alt="Instagram"></a>
        </div>
    </div>

    <!-- Copyright -->
    <div class="footer-bottom">
        <p>© <?= date('Y'); ?> Design & Developed By Mustak Aalam. All Rights Reserved.</p>
    </div>
</footer>
