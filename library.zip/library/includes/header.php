
<header>
    <div class="top-bar">
        <h1>Library Seat Booking</h1>
        <div class="user-profile">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php">
                    <img src="uploads" width="40" height="40">
                    My Account
                </a>
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif; ?>
        </div>
    </div>
</header>
