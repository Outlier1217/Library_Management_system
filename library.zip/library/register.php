<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Image Upload Handling
    $target_dir = "uploads/";
    $default_image = "default.png"; // Default profile image
    $image_name = $default_image;

    if (!empty($_FILES["profile_image"]["name"])) {
        $image_name = time() . "_" . basename($_FILES["profile_image"]["name"]);
        $target_file = $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Validate file type (Only allow JPG, PNG, GIF)
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file)) {
                // File successfully uploaded
            } else {
                echo "Error uploading file.";
                exit();
            }
        } else {
            echo "Invalid file format. Allowed: JPG, PNG, GIF.";
            exit();
        }
    }

    // Insert user data into the database
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, profile_image) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $image_name);

    if ($stmt->execute()) {
        header("Location: login.php?success=registered");
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
   
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<style>
/* General Styles */
body {
    font-family: 'Poppins', sans-serif;
    background: radial-gradient(circle, rgb(44, 29, 29) 0%, rgb(85, 83, 83) 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

/* Wrapper */
.auth-wrapper {
    width: 100%;
    max-width: 400px;
}

/* Auth Box */
.auth-box {
    background: rgba(255, 255, 255, 0.1);
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0px 0px 15px rgba(255, 0, 150, 0.3);
    text-align: center;
    backdrop-filter: blur(10px);
    animation: fadeIn 0.5s ease-in-out;
}

/* Title */
.auth-box h2 {
    color: #ff007f;
    font-size: 24px;
    margin-bottom: 20px;
}

/* Input Groups */
.input-group {
    position: relative;
    margin-bottom: 15px;
}

.input-group input {
    width: 100%;
    padding: 12px 10px;
    border: none;
    border-bottom: 2px solid #ff007f;
    background: transparent;
    color: white;
    font-size: 16px;
    outline: none;
    transition: 0.3s;
}

.input-group label {
    position: absolute;
    top: 10px;
    left: 10px;
    font-size: 14px;
    color: rgba(255, 255, 255, 0.6);
    transition: 0.3s;
}

/* Floating Label Effect */
.input-group input:focus ~ label,
.input-group input:valid ~ label {
    top: -10px;
    font-size: 12px;
    color: #ff007f;
}

.input-group i {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(255, 255, 255, 0.6);
}

/* File Input */
.file-input input {
    opacity: 0;
    position: absolute;
    width: 100%;
    height: 40px;
    cursor: pointer;
}

.file-input label {
    position: relative;
    display: block;
    padding: 10px;
    background: rgba(255, 0, 150, 0.2);
    color: white;
    border-radius: 5px;
    cursor: pointer;
}

/* Button */
.auth-btn {
    background: #ff007f;
    color: white;
    border: none;
    width: 100%;
    padding: 12px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

.auth-btn:hover {
    background: #d60069;
}

/* Footer Links */
.auth-footer {
    margin-top: 15px;
}

.auth-footer a {
    text-decoration: none;
    color: #ff007f;
}

.auth-footer a:hover {
    text-decoration: underline;
}

/* Animation */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Responsive */
@media screen and (max-width: 500px) {
    .auth-wrapper {
        width: 90%;
    }
}



   </style>
<body>
    <div class="auth-container">
        <h2>Create an Account</h2>
        <form action="register.php" method="POST" enctype="multipart/form-data">
            <div class="input-group">
                <input type="text" name="name" placeholder="Full Name" required>
                <i class="fas fa-user"></i>
            </div>
            <div class="input-group">
                <input type="email" name="email" placeholder="Email Address" required>
                <i class="fas fa-envelope"></i>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
                <i class="fas fa-lock"></i>
            </div>
            <div class="input-group">
                <input type="file" name="profile_image" accept="image/*">
                <i class="fas fa-image"></i>
            </div>
            <button type="submit" class="auth-btn">Register</button>
        </form>
        <div class="auth-links">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>

   
</body>
</html>
