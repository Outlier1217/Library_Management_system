<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if token exists and is valid
    $stmt = $conn->prepare("SELECT email FROM password_resets WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $email = $row['email'];

        // Update password in users table
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $new_password, $email);
        $stmt->execute();

        // Delete used token
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $success_message = "Password has been updated. <a href='login.php'>Login here</a>";
    } else {
        $error_message = "Invalid or expired token.";
    }
} else {
    $token = $_GET['token'] ?? '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* General Styles */
        body {
            font-family: 'Poppins', sans-serif;
            background: url('../img/reset-password-bg.jpg') no-repeat center center/cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Wrapper */
        .reset-wrapper {
            width: 100%;
            max-width: 400px;
        }

        /* Reset Password Box */
        .reset-box {
            background: rgba(255, 255, 255, 0.2);
            padding: 35px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            animation: fadeIn 0.5s ease-in-out;
            transition: 0.3s;
        }

        .reset-box:hover {
            transform: scale(1.02);
        }

        /* Title */
        .reset-box h2 {
            font-size: 26px;
            color: black;
            margin-bottom: 10px;
        }

        /* Subtitle */
        .subtitle {
            font-size: 14px;
            color: rgb(13, 2, 2);
            margin-bottom: 20px;
        }

        /* Success & Error Messages */
        .message {
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .success-msg {
            color: #28a745;
            background: rgba(40, 167, 69, 0.2);
        }

        .error-msg {
            color: #ff4d4d;
            background: rgba(255, 0, 0, 0.15);
        }

        /* Input Group */
        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 10px;
            border: none;
            border-bottom: 2px solid #ff007f;
            background: transparent;
            color: black;
            font-size: 16px;
            outline: none;
            transition: 0.3s;
        }

        /* Floating Label Effect */
        .input-group label {
            position: absolute;
            top: 10px;
            left: 10px;
            font-size: 14px;
            color: rgba(255, 255, 255, 0.6);
            transition: 0.3s;
        }

        .input-group input:focus ~ label,
        .input-group input:valid ~ label {
            top: -10px;
            font-size: 12px;
            color: #ff007f;
        }

        /* Input Icons */
        .input-group i {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.8);
        }

        /* Reset Button */
        .reset-btn {
            background: #ff007f;
            color: white;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .reset-btn:hover {
            background: #d60069;
            transform: scale(1.05);
        }

        /* Login Links */
        .reset-links {
            margin-top: 15px;
            font-size: 14px;
        }

        .reset-links a {
            color: black;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .reset-links a:hover {
            text-decoration: underline;
            color: rgb(174, 141, 8);
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media screen and (max-width: 500px) {
            .reset-wrapper {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="reset-wrapper">
        <div class="reset-box">
            <h2>Reset Password</h2>
            <p class="subtitle">Enter a new password below</p>
            <?php if (isset($success_message)) : ?>
                <p class="message success-msg"><?= $success_message; ?></p>
            <?php endif; ?>
            <?php if (isset($error_message)) : ?>
                <p class="message error-msg"><?= $error_message; ?></p>
            <?php endif; ?>
            <form action="" method="POST">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" required placeholder="New Password">
                </div>
                <button type="submit" class="reset-btn">Reset Password</button>
            </form>
            <div class="reset-links">
                <a href="login.php">Back to Login</a>
            </div>
        </div>
    </div>
</body>
</html>
