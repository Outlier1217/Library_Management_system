<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$booking = $conn->query("SELECT b.*, u.name, s.seat_number FROM bookings b 
                         JOIN users u ON b.user_id = u.id
                         JOIN seats s ON b.seat_id = s.id
                         WHERE b.user_id=$user_id ORDER BY b.id DESC LIMIT 1")->fetch_assoc();
                         


$formatted_start_date = date("d-m-Y", strtotime($booking['start_date']));
$formatted_end_date = date("d-m-Y", strtotime($booking['end_date']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - LM Library</title>
    <style>
        body { font-family: 'Poppins', sans-serif; text-align: center; background: #fff; padding: 20px; }
        .invoice { max-width: 500px; margin: auto; padding: 20px; border: 1px solid #ccc; }
        .invoice img { width: 100px; margin-bottom: 10px; }
        .details p { font-size: 16px; margin: 5px 0; }
    </style>
</head>
<body>

<div class="invoice">
    <img src="images/library.png" alt="Library Logo">
    <h2>LM Library Invoice</h2>
    <div class="details">
        <p><strong>Name:</strong> <?= $booking['name']; ?></p>
        <p><strong>Seat No:</strong> <?= $booking['seat_number']; ?></p>
        <p><strong>Credits Used:</strong> ₹<?= $booking['subscription_plan']; ?></p>

        <p><strong>Booking Date:</strong> <?= $formatted_start_date; ?></p>
        <p><strong>Expiry Date:</strong> <?= $formatted_end_date; ?></p>
    </div>
</div>

</body>
</html>
