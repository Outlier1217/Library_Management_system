<?php
include "config.php";

// Find expired bookings
$current_date = date('Y-m-d');
$expired_bookings = $conn->query("SELECT id, seat_id FROM bookings WHERE expiry_date <= '$current_date' AND status = 'confirmed'");

while ($booking = $expired_bookings->fetch_assoc()) {
    $conn->begin_transaction();
    try {
        // Update booking status
        $conn->query("UPDATE bookings SET status = 'expired' WHERE id = {$booking['id']}");
        // Free the seat
        $conn->query("UPDATE seats SET status = 'available' WHERE id = {$booking['seat_id']}");
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Failed to expire booking {$booking['id']}: " . $e->getMessage());
    }
}

echo "Expired bookings processed successfully.";
?>