<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check and expire old bookings
$current_date = date('Y-m-d');
$conn->query("UPDATE bookings b 
    JOIN seats s ON b.seat_id = s.id 
    SET b.status = 'expired', s.status = 'available' 
    WHERE b.expiry_date <= '$current_date' AND b.status IN ('confirmed', 'reserved')");

// Fetch user's existing active booking or reservation
$existing_booking = $conn->query("
    SELECT b.*, s.seat_number, s.status 
    FROM bookings b 
    JOIN seats s ON b.seat_id = s.id 
    WHERE b.user_id = $user_id AND b.status IN ('confirmed', 'reserved') AND s.status IN ('booked', 'reserved')
    LIMIT 1
")->fetch_assoc();

$has_active_booking = !empty($existing_booking);
$booked_seat_number = $existing_booking['seat_number'] ?? null;

if ($has_active_booking) {
    $type = $existing_booking['status'] === 'confirmed' ? 'booked' : 'reserved';
    echo "<script>
        alert('You already have a $type seat (Seat Number: $booked_seat_number). You cannot book or reserve another seat. Please cancel your existing $type seat first.');
        window.location.href = 'dashboard.php';
    </script>";
    exit();
}

// Check if this is a reservation request
$is_reservation = isset($_GET['reserve']) && $_GET['reserve'] == 1;

// Get all seats
$seats = $conn->query("SELECT * FROM seats ORDER BY seat_number ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $is_reservation ? 'Reserve Your Seat' : 'Book Your Seat'; ?> - LM Library</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        :root {
            --primary-color: #ff9800;
            --available-color: #28a745;
            --booked-color: #dc3545;
            --reserved-color: #6c757d;
            --selected-color: #ffc107;
            --text-color: #fff;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #444);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        .booking-container {
            background: rgba(255, 255, 255, 0.15);
            padding: 30px;
            border-radius: 12px;
            backdrop-filter: blur(12px);
            box-shadow: var(--shadow);
            width: 90%;
            max-width: 800px;
            text-align: center;
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            font-size: 28px;
            margin-bottom: 20px;
            color: var(--text-color);
        }

        h3 {
            font-size: 20px;
            margin: 20px 0 15px;
            color: var(--text-color);
        }

        .seat-map {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(50px, 1fr));
            gap: 15px;
            justify-content: center;
            margin-top: 25px;
        }

        .seat {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
        }

        .available {
            background: var(--available-color);
            box-shadow: 0 0 10px rgba(40, 167, 69, 0.5);
        }

        .available:hover {
            transform: scale(1.1);
            background: #218838;
        }

        .booked {
            background: var(--booked-color);
            opacity: 0.6;
            pointer-events: none;
        }

        .reserved {
            background: var(--reserved-color);
            opacity: 0.6;
            pointer-events: none;
        }

        .reserved:hover::after {
            content: "Already Reserved";
            position: absolute;
            top: -35px;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
            z-index: 10;
        }

        .selected {
            background: var(--selected-color);
            color: #000;
            box-shadow: 0 0 15px rgba(255, 193, 7, 0.7);
        }

        .pricing-options {
            margin: 20px 0;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .pricing-options label {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
        }

        .pricing-options label:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .pricing-options input[type="radio"] {
            margin-right: 10px;
        }

        .voucher-section {
            margin: 25px 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .voucher-section input {
            width: 80%;
            max-width: 300px;
            padding: 12px;
            border: 2px solid white;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 16px;
            outline: none;
            transition: var(--transition);
        }

        .voucher-section input:focus {
            border-color: var(--primary-color);
        }

        .voucher-section button {
            padding: 12px 20px;
            border: none;
            background: var(--primary-color);
            color: white;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: var(--transition);
        }

        .voucher-section button:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        .voucher-section p {
            font-size: 14px;
            color: var(--text-color);
        }

        .book-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            width: 100%;
            max-width: 300px;
            padding: 14px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 20px;
        }

        .book-btn:hover {
            background: #e68900;
            transform: scale(1.05);
        }

        .library-images {
            margin-top: 40px;
            text-align: center;
            width: 90%;
            max-width: 600px;
        }

        .library-images h3 {
            color: var(--text-color);
            font-size: 18px;
            margin: 15px 0 10px;
        }

        .library-images img {
            width: 100%;
            border-radius: 12px;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .library-images img:hover {
            transform: scale(1.02);
        }

        @media (max-width: 768px) {
            .booking-container {
                padding: 20px;
            }

            .seat-map {
                grid-template-columns: repeat(auto-fit, minmax(40px, 1fr));
                gap: 10px;
            }

            .seat {
                width: 40px;
                height: 40px;
                font-size: 14px;
            }

            .pricing-options label {
                font-size: 14px;
            }

            .voucher-section input {
                width: 100%;
            }

            .book-btn {
                padding: 12px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <div class="booking-container">
        <h2><?php echo $is_reservation ? 'Reserve Your Seat' : 'Select Your Seat'; ?></h2>
        <div class="seat-map">
            <?php while ($seat = $seats->fetch_assoc()): ?>
                <div class="seat <?= htmlspecialchars($seat['status']); ?>" 
                     data-id="<?= $seat['id']; ?>"
                     title="<?= $seat['status'] === 'reserved' ? 'Already Reserved' : ($seat['status'] === 'booked' ? 'Already Booked' : 'Available'); ?>">
                    <?= htmlspecialchars($seat['seat_number']); ?>
                </div>
            <?php endwhile; ?>
        </div>

        <h3>Choose Your Subscription Plan</h3>
        <form action="<?php echo $is_reservation ? 'process_reservation.php' : 'process_booking.php'; ?>" method="POST">
            <input type="hidden" id="selected-seat" name="seat_id" required>
            <div class="pricing-options">
                <label><input type="radio" name="plan" value="500" required> ₹500/month <?php echo $is_reservation ? '(₹125 to reserve)' : ''; ?></label>
                <label><input type="radio" name="plan" value="750"> ₹750/month <?php echo $is_reservation ? '(₹188 to reserve)' : ''; ?></label>
                <label><input type="radio" name="plan" value="850"> ₹850/month <?php echo $is_reservation ? '(₹213 to reserve)' : ''; ?></label>
            </div>

            <div class="voucher-section">
                <input type="text" name="voucher_code" id="voucher_code" placeholder="Enter Voucher Code (Optional)">
                <button type="button" onclick="applyVoucher()">Apply Voucher</button>
                <p id="voucherMessage"></p>
            </div>

            <button type="submit" class="book-btn"><?php echo $is_reservation ? 'Confirm Reservation' : 'Confirm Booking'; ?></button>
        </form>
    </div>

    <div class="library-images">
        <h3>NIMS Library Seating Plan</h3>
        <img src="images/nims.jpg" alt="NIMS Library Seating Plan">
        <h3>LAL KOTHI Library Seating Plan</h3>
        <img src="images/lal_kothi.jpg" alt="LAL KOTHI Library Seating Plan">
    </div>

    <script>
        document.querySelectorAll('.seat.available').forEach(seat => {
            seat.addEventListener('click', function() {
                document.querySelectorAll('.seat').forEach(s => s.classList.remove('selected'));
                this.classList.add('selected');
                document.getElementById('selected-seat').value = this.dataset.id;
            });
        });

        function applyVoucher() {
            const voucherCode = document.getElementById("voucher_code").value.trim();
            if (!voucherCode) {
                document.getElementById("voucherMessage").innerHTML = "Please enter a voucher code.";
                return;
            }

            fetch("apply_voucher.php?voucher_code=" + encodeURIComponent(voucherCode))
                .then(response => {
                    if (!response.ok) throw new Error("Network response was not ok");
                    return response.text();
                })
                .then(data => {
                    document.getElementById("voucherMessage").innerHTML = data;
                    // Optionally clear input on success
                    if (data.includes("successfully")) {
                        document.getElementById("voucher_code").value = "";
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    document.getElementById("voucherMessage").innerHTML = "Error applying voucher.";
                });
        }
    </script>
</body>
</html>