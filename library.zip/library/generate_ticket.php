<?php
require('libs/fpdf.php');
require('phpqrcode/phpqrcode.php');
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
error_log("User ID in generate_ticket.php: $user_id");

// Fetch booking details
$booking = $conn->query("
    SELECT b.*, u.name, u.email, s.seat_number, s.status AS seat_status 
    FROM bookings b 
    JOIN users u ON b.user_id = u.id 
    JOIN seats s ON b.seat_id = s.id 
    WHERE b.user_id = $user_id 
    ORDER BY b.id DESC 
    LIMIT 1
")->fetch_assoc();

// Debug booking data
if ($booking) {
    error_log("Booking found: ID={$booking['id']}, Status={$booking['status']}, Seat={$booking['seat_number']}, Seat Status={$booking['seat_status']}");
} else {
    error_log("No booking found for user_id: $user_id");
}

// Check booking status
if (!$booking || $booking['status'] !== 'confirmed') {
    echo "<script>alert('No active booking found. Please book a seat first.'); window.location.href='booking.php';</script>";
    exit();
}

// Verify seat status consistency
if ($booking['status'] === 'confirmed' && $booking['seat_status'] !== 'booked') {
    error_log("Seat status mismatch: Booking confirmed but seat not booked. Fixing...");
    $conn->query("UPDATE seats SET status = 'booked' WHERE id = {$booking['seat_id']}");
}

// Calculate dates if invalid
$start_date = $booking['start_date'] === '0000-00-00' ? date('Y-m-d') : $booking['start_date'];
$expiry_date = $booking['expiry_date'] === '0000-00-00' ? date('Y-m-d', strtotime('+30 days')) : $booking['expiry_date'];

// Convert date format to DD-MM-YYYY
$formatted_start_date = date("d-m-Y", strtotime($start_date));
$formatted_expiry_date = date("d-m-Y", strtotime($expiry_date));

// Generate QR Code Data
$qrData = "Name: {$booking['name']}\nEmail: {$booking['email']}\nSeat No: {$booking['seat_number']}\nPlan: ₹{$booking['amount_paid']}\nBooked On: {$formatted_start_date}\nExpiry: {$formatted_expiry_date}";

// Define QR Code Path
$qrCodePath = "uploads/qrcodes/ticket_{$booking['id']}.png";

// Generate and Save QR Code
QRcode::png($qrData, $qrCodePath, QR_ECLEVEL_L, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Ticket - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #fff;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1a1a1a, #444);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .ticket-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 16px;
            box-shadow: var(--shadow);
            max-width: 400px;
            width: 100%;
            text-align: center;
            color: #333;
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.5s ease-in-out;
        }

        .ticket-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 152, 0, 0.1) 0%, transparent 70%);
            transform: rotate(30deg);
            z-index: -1;
        }

        h2 {
            font-size: 26px;
            color: var(--primary-color);
            margin-bottom: 20px;
            font-weight: 600;
        }

        .ticket-details {
            background: #fff3e0;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .ticket-details p {
            font-size: 16px;
            margin: 10px 0;
            color: #555;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .ticket-details p strong {
            color: #333;
            font-weight: 500;
        }

        .ticket-details img {
            margin-top: 20px;
            max-width: 150px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .download-btn {
            display: inline-block;
            padding: 12px 25px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .download-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 152, 0, 0.4);
        }

        .download-btn i {
            margin-right: 8px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .ticket-container {
                padding: 25px;
                max-width: 100%;
            }

            h2 {
                font-size: 22px;
            }

            .ticket-details p {
                font-size: 14px;
                flex-direction: column;
                text-align: left;
            }

            .ticket-details img {
                max-width: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="ticket-container">
        <h2><i class="fa-solid fa-ticket-alt"></i> Your Booking Ticket</h2>
        <div class="ticket-details">
            <p><strong>Name:</strong> <span><?= htmlspecialchars($booking['name']); ?></span></p>
            <p><strong>Email:</strong> <span><?= htmlspecialchars($booking['email']); ?></span></p>
            <p><strong>Seat No:</strong> <span><?= htmlspecialchars($booking['seat_number']); ?></span></p>
            <p><strong>Plan:</strong> <span>₹<?= htmlspecialchars($booking['amount_paid']); ?>/month</span></p>
            <p><strong>Booked On:</strong> <span><?= htmlspecialchars($formatted_start_date); ?></span></p>
            <p><strong>Expiry:</strong> <span><?= htmlspecialchars($formatted_expiry_date); ?></span></p>
            <img src="<?= htmlspecialchars($qrCodePath); ?>" alt="QR Code">
        </div>
        <a href="download_ticket.php?booking_id=<?= htmlspecialchars($booking['id']); ?>" class="download-btn">
            <i class="fa-solid fa-download"></i> Download Ticket
        </a>
    </div>
</body>
</html>