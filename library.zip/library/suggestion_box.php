<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $suggestion = trim($_POST['suggestion']);
    if (!empty($suggestion)) {
        $stmt = $conn->prepare("INSERT INTO suggestions (user_id, suggestion) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $suggestion);
        if ($stmt->execute()) {
            $message = "<p class='success'>Suggestion submitted successfully!</p>";
        } else {
            $message = "<p class='error'>Error submitting suggestion. Please try again.</p>";
        }
    } else {
        $message = "<p class='error'>Suggestion cannot be empty.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suggestion Box - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .suggestion-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }

        .suggestion-container h2 {
            color: #ff9800;
            margin-bottom: 20px;
            text-align: center;
        }

        .suggestion-container form {
            display: flex;
            flex-direction: column;
        }

        .suggestion-container textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            resize: vertical;
            min-height: 100px;
            margin-bottom: 15px;
            font-family: 'Poppins', sans-serif;
        }

        .suggestion-container button {
            padding: 10px;
            background: #ff9800;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .suggestion-container button:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        .suggestion-container .success {
            color: #4CAF50;
            text-align: center;
        }

        .suggestion-container .error {
            color: #e74c3c;
            text-align: center;
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #ff9800;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .back-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="suggestion-container">
        <h2>Suggestion Box</h2>
        <?= $message; ?>
        <form method="POST">
            <textarea name="suggestion" placeholder="Enter your suggestion here..." required></textarea>
            <button type="submit">Submit Suggestion</button>
        </form>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>
</body>
</html>