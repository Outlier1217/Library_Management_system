<?php 
include "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LM Library</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="images/logo.png" type="image/x-icon">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* Global Styling */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f7f6;
            color: #333;
        }

        /* Navbar */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: #2c3e50;
            color: white;
            position: relative;
            z-index: 100;
        }

        .navbar .logo img {
            height: 50px;
        }

        .burger-menu {
            display: none;
            font-size: 28px;
            cursor: pointer;
        }

        .menu {
            display: flex;
            gap: 20px;
        }

        .menu a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 5px;
            transition: 0.3s;
        }

        .menu a:hover {
            background: #f39c12;
        }

        /* Full-screen mobile menu */
        .mobile-menu {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(44, 62, 80, 0.95);
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 200;
        }

        .mobile-menu a {
            color: white;
            font-size: 24px;
            text-decoration: none;
            margin: 15px 0;
        }

        .mobile-menu a:hover {
            color: #f39c12;
        }

        .close-menu {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 30px;
            cursor: pointer;
            color: white;
        }

        /* Hero Section */
        .hero {
            position: relative;
            text-align: center;
            color: white;
            height: 80vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: url('images/first_image.jpg') center/cover no-repeat;
        }

        .hero::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }

        .hero-text {
            position: relative;
            z-index: 1;
            text-align: center;
        }

        .hero h1 {
            font-size: 42px;
            margin-bottom: 10px;
        }

        .hero p {
            font-size: 20px;
        }

        /* Subscription Plans */
        .subscription-plans {
            text-align: center;
            padding: 50px 20px;
            background: #ecf0f1;
        }

        .plans {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .plan {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            width: 250px;
            text-align: center;
        }

        .plan h4 {
            font-size: 22px;
            color: #2c3e50;
        }

        .plan p {
            font-size: 16px;
        }

        /* Contact Form */
        .contact-form {
            text-align: center;
            padding: 50px 20px;
        }

        .contact-form form {
            max-width: 400px;
            margin: auto;
        }

        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .contact-form button {
            background: #f39c12;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }

        .contact-form button:hover {
            background: #d68910;
        }

        /* Responsive Design */
        @media screen and (max-width: 768px) {
            .menu {
                display: none;
            }

            .burger-menu {
                display: block;
            }

            .plans {
                flex-direction: column;
                align-items: center;
            }

            .plan {
                width: 80%;
            }
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <img src="images/library.png" alt="Library Logo">
        </div>
        <div class="burger-menu" onclick="openMenu()">☰</div>
        <div class="menu">
            <a href="index.php">Home</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
            
            
            <a href="booking.php">Quick Booking</a>
        </div>
    </nav>

    <!-- Mobile Fullscreen Menu -->
    <div class="mobile-menu" id="mobileMenu">
        <div class="close-menu" onclick="closeMenu()">✖</div>
        <a href="index.php">Home</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        
        
        <a href="booking.php">Quick Booking</a>
    </div>

    <header class="hero">
        <div class="hero-text">
            <h1>Welcome to LM Library</h1>
            <p>Your perfect space for study and research. Book your seat now!</p>
        </div>
    </header>

    <!-- Subscription Plans -->
    <section class="subscription-plans">
        <h3>Choose Your Plan</h3>
        <div class="plans">
            <div class="plan">
                <h4>₹500/month</h4>
                <p>Day-wise plans available</p>
            </div>
            <div class="plan">
                <h4>₹750/month</h4>
                <p>More flexible access</p>
            </div>
            <div class="plan">
                <h4>₹850/month</h4>
                <p>Best for regular users</p>
            </div>
        </div>
    </section>

    <!-- Contact Form -->
    <section class="contact-form">
        <h3>Contact Us</h3>
        <form action="contact_process.php" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
        </form>

        <!-- Success/Error Messages -->
<?php
if (isset($_GET['success'])) {
    echo "<p style='color: green;'>Your message has been sent successfully!</p>";
}
if (isset($_GET['error'])) {
    echo "<p style='color: red;'>There was an error. Please try again.</p>";
}
?>
    </section>

    <script>
        function openMenu() {
            document.getElementById("mobileMenu").style.display = "flex";
        }

        function closeMenu() {
            document.getElementById("mobileMenu").style.display = "none";
        }
    </script>

    <?php include "includes/footer.php"; ?>

</body>
</html>
