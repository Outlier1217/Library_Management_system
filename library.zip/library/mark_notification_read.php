<?php
include "config.php";
session_start();

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();

// Get remaining unread count (should be 0)
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$count = $stmt->get_result()->fetch_assoc()['count'];

echo $count;
?>