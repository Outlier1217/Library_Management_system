<?php
session_start();
include "config.php";

echo "<h2>Paytm Payment Response</h2>";
echo "<pre>";
print_r($_POST); // Shows Paytm's full response
echo "</pre>";
exit(); // Stop execution to check the output
require_once("paytm/PaytmChecksum.php");

// Paytm Merchant Key
$paytm_merchant_key = "kkqcK0W8I0HBV9nH";

// Read Paytm Response
$paytm_response = $_POST;
$paytm_checksum = isset($paytm_response["CHECKSUMHASH"]) ? $paytm_response["CHECKSUMHASH"] : "";

// Log Paytm response for debugging
file_put_contents("paytm_response_log.txt", print_r($paytm_response, true), FILE_APPEND);

// Verify Checksum
$verify_checksum = PaytmChecksum::verifySignature($paytm_response, $paytm_merchant_key, $paytm_checksum);

// Log verification status
file_put_contents("checksum_debug.txt", "Checksum Verified: " . ($verify_checksum ? "YES" : "NO") . "\n", FILE_APPEND);

if ($verify_checksum !== true) {
    die("Checksum verification failed! Check checksum_debug.txt for details.");
}


// Paytm Merchant Key
$paytm_merchant_key = "kkqcK0W8I0HBV9nH";

// Read Paytm Response
$paytm_response = $_POST;
$paytm_checksum = isset($paytm_response["CHECKSUMHASH"]) ? $paytm_response["CHECKSUMHASH"] : "";

// Log Paytm response for debugging
file_put_contents("paytm_log.txt", print_r($paytm_response, true)); // Check this file for issues

// Verify Checksum
$verify_checksum = PaytmChecksum::verifySignature($paytm_response, $paytm_merchant_key, $paytm_checksum);

if ($verify_checksum === true && isset($paytm_response["STATUS"])) {
    $status = $paytm_response["STATUS"];
    $order_id = $paytm_response["ORDERID"];
    $transaction_id = isset($paytm_response["TXNID"]) ? $paytm_response["TXNID"] : "N/A";
    $amount = isset($paytm_response["TXNAMOUNT"]) ? $paytm_response["TXNAMOUNT"] : "N/A";
    $user_id = $_SESSION['user_id'];

    if ($status === "TXN_SUCCESS") {
        // Update booking status in database
        $conn->query("UPDATE bookings SET payment_status='Paid', transaction_id='$transaction_id' WHERE user_id='$user_id' AND subscription_plan='$amount'");

        // Redirect to success page
        header("Location: success.php");
        exit();
    } else {
        // Log failure details
        file_put_contents("paytm_error_log.txt", "Failed Transaction: " . print_r($paytm_response, true));

        // Redirect to failure page
        header("Location: failure.php");
        exit();
    }
} else {
    // Log checksum failure
    file_put_contents("paytm_error_log.txt", "Checksum Verification Failed: " . print_r($paytm_response, true));

    // Redirect to failure page
    header("Location: failure.php");
    exit();
}
?>
