<?php
include "includes/db_connect.php";
include "phpqrcode/qrlib.php";

$booking_id = $_GET['booking_id'];
$booking = $conn->query("SELECT * FROM bookings WHERE id=$booking_id")->fetch_assoc();

$qr_data = "User: {$booking['user_id']} | Seat: {$booking['seat_id']} | Expiry: {$booking['end_date']}";
$qr_file = "uploads/qrcodes/ticket_$booking_id.png";
QRcode::png($qr_data, $qr_file);

echo "<h2>Your Ticket</h2>";
echo "<img src='$qr_file'>";
?>
