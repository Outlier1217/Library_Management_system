<?php
include "includes/db_connect.php";
session_start();

if (!isset($_SESSION['user_id']) || !isset($_POST['seat_id']) || !isset($_POST['plan'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$seat_id = $_POST['seat_id'];
$plan = $_POST['plan'];
$start_date = date("Y-m-d");
$end_date = date("Y-m-d", strtotime("+30 days"));

$conn->query("UPDATE seats SET status='booked' WHERE id=$seat_id");

$stmt = $conn->prepare("INSERT INTO bookings (user_id, seat_id, subscription_plan, start_date, end_date) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("iisss", $user_id, $seat_id, $plan, $start_date, $end_date);
$stmt->execute();

header("Location: dashboard.php?success=booked");
?>
