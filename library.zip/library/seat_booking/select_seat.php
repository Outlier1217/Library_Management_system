<?php
include "includes/db_connect.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$seats = $conn->query("SELECT * FROM seats");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Select Seat</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h2>Choose Your Seat</h2>
    <div class="seat-container">
        <?php while ($seat = $seats->fetch_assoc()): ?>
            <div class="seat <?= $seat['status']; ?>" data-id="<?= $seat['id']; ?>">
                Seat <?= $seat['seat_number']; ?>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
