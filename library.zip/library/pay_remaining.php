<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$user = $conn->query("SELECT name, credits FROM users WHERE id = $user_id")->fetch_assoc();
$credits = round($user['credits']);

// Fetch reservation details
$reservation = $conn->query("
    SELECT b.*, s.seat_number 
    FROM bookings b 
    JOIN seats s ON b.seat_id = s.id 
    WHERE b.user_id = $user_id AND b.status = 'reserved'
")->fetch_assoc();

if (!$reservation) {
    echo "<script>alert('No reserved seat found.'); window.location.href='dashboard.php';</script>";
    exit();
}

$remaining_amount = $reservation['total_amount'] - $reservation['amount_paid'];
$reserved_date = date("d-m-Y", strtotime($reservation['start_date']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Remaining Amount</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .payment-container {
            background: rgba(255, 255, 255, 0.2);
            padding: 30px;
            border-radius: 12px;
            backdrop-filter: blur(12px);
            box-shadow: 0px 4px 15px rgba(255, 255, 255, 0.1);
            width: 90%;
            max-width: 400px;
        }
        h2 {
            font-size: 26px;
            margin-bottom: 15px;
        }
        .payment-details p {
            font-size: 16px;
            margin: 10px 0;
        }
        .pay-btn {
            background: #ff9800;
            padding: 12px;
            border: none;
            color: white;
            font-size: 16px;
            width: 100%;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
        }
        .pay-btn:hover {
            background: #e68900;
        }
    </style>
</head>
<body>
    <div class="payment-container">
        <h2>Pay Remaining Amount</h2>
        <div class="payment-details">
            <p><strong>Name:</strong> <?= $user['name']; ?></p>
            <p><strong>Reserved Date:</strong> <?= $reserved_date; ?></p>
            <p><strong>Seat Number:</strong> <?= $reservation['seat_number']; ?></p>
            <p><strong>Current Credits:</strong> <?= $credits; ?> LM</p>
        </div>
        <button class="pay-btn" onclick="confirmPayment(<?= $remaining_amount; ?>, <?= $credits; ?>, <?= $reservation['id']; ?>)">
            Pay ₹<?= $remaining_amount; ?>
        </button>
    </div>

    <script>
        function confirmPayment(remainingAmount, credits, bookingId) {
            if (credits < remainingAmount) {
                alert("Insufficient LM Credits. Please recharge first.");
                window.location.href = "add_credits.php";
                return;
            }

            if (confirm(`Are you sure you want to pay ₹${remainingAmount} to confirm your booking?`)) {
                fetch("process_payment.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: `booking_id=${bookingId}&amount=${remainingAmount}`
                })
                .then(response => response.text())
                .then(data => {
                    if (data === "success") {
                        alert("Payment successful! Your booking is now confirmed.");
                        window.location.href = "generate_ticket.php";
                    } else {
                        alert("Payment failed: " + data);
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("An error occurred. Please try again.");
                });
            }
        }
    </script>
</body>
</html>