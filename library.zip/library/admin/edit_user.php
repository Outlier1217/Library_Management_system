<?php
include "config.php";


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("User ID not provided!");
}

$user_id = $_GET['id'];
$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $conn->query("UPDATE users SET name='$name', email='$email' WHERE id=$user_id");
    header("Location: manage_users.php?success=User Updated");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
    <div class="admin-container">
        <h2>Edit User</h2>
        <form action="edit_user.php?id=<?= $user_id; ?>" method="POST">
            <input type="text" name="name" value="<?= $user['name']; ?>" required>
            <input type="email" name="email" value="<?= $user['email']; ?>" required>
            <button type="submit">Update User</button>
        </form>
        <a href="manage_users.php">Back</a>
    </div>
</body>
</html>
