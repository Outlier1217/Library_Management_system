<?php
include "config.php";


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

$bookings = $conn->query("SELECT b.*, u.name, u.email, s.seat_number FROM bookings b 
                          JOIN users u ON b.user_id = u.id
                          JOIN seats s ON b.seat_id = s.id ORDER BY b.id DESC");

// Cancel a Booking
if (isset($_GET['cancel_id'])) {
    $booking_id = $_GET['cancel_id'];
    $seat_id = $_GET['seat_id'];

    // Delete booking and mark seat as available
    $conn->query("DELETE FROM bookings WHERE id=$booking_id");
    $conn->query("UPDATE seats SET status='available' WHERE id=$seat_id");

    header("Location: manage_bookings.php?success=Booking Cancelled");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings</title>
    <link rel="stylesheet" href="assets/css/admin.css">
</head>

<style>

    /* General Styles */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background: #f5f5f5;
}

/* Admin Layout */
.admin-main {
    padding: 30px;
    background: white;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    max-width: 1200px;
    margin: auto;
}

.admin-main h2 {
    font-size: 28px;
    color: #333;
}

.admin-main p {
    font-size: 16px;
    color: #666;
}

/* Bookings Table */
.bookings-table-container {
    margin-top: 20px;
    overflow-x: auto;
}

.bookings-table {
    width: 100%;
    border-collapse: collapse;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 10px;
    backdrop-filter: blur(10px);
    box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
}

.bookings-table thead {
    background: #ff6600;
    color: white;
}

.bookings-table th,
.bookings-table td {
    padding: 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.bookings-table th {
    font-size: 16px;
    text-transform: uppercase;
}

.bookings-table tbody tr:hover {
    background: rgba(255, 165, 0, 0.1);
}

/* Seat Number Styling */
.seat-number {
    font-weight: bold;
    color: #008c76;
}

/* Cancel Button */
.cancel-btn {
    display: inline-block;
    padding: 8px 12px;
    background: #ff3b3b;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    transition: 0.3s;
}

.cancel-btn:hover {
    background: #c50000;
}

/* Responsive Design */
@media screen and (max-width: 1024px) {
    .bookings-table-container {
        overflow-x: scroll;
    }
}

@media screen and (max-width: 600px) {
    .admin-main {
        padding: 20px;
    }

    .bookings-table th,
    .bookings-table td {
        font-size: 14px;
    }

    .cancel-btn {
        padding: 6px 10px;
        font-size: 12px;
    }
}

</style>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2>📅 Manage Bookings</h2>
        <p>View and manage active seat bookings.</p>

        <div class="bookings-table-container">
            <table class="bookings-table">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Seat No</th>
                        <th>Plan</th>
                        <th>Expiry Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($booking = $bookings->fetch_assoc()) : ?>
                        <tr>
                            <td><?= $booking['id']; ?></td>
                            <td><?= $booking['name']; ?></td>
                            <td><?= $booking['email']; ?></td>
                            <td class="seat-number"><?= $booking['seat_number']; ?></td>
                            <td>₹<?= $booking['subscription_plan']; ?>/month</td>
                            <td><?= $booking['expiry_date']; ?></td>
                            <td>
                                <a href="manage_bookings.php?cancel_id=<?= $booking['id']; ?>&seat_id=<?= $booking['seat_id']; ?>"
                                   onclick="return confirm('Are you sure you want to cancel this booking?')"
                                   class="cancel-btn">❌ Cancel</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
