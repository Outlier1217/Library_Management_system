<?php
include "config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Fetch all users along with seat booking info and expiry date
$users = $conn->query("
    SELECT users.*, seats.seat_number, bookings.expiry_date
    FROM users 
    LEFT JOIN bookings ON users.id = bookings.user_id 
    LEFT JOIN seats ON bookings.seat_id = seats.id
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="assets/css/admin.css">
</head>
<style>
    /* General Styles */
    body {
        font-family: 'Poppins', sans-serif;
        margin: 0;
        padding: 0;
        background: #f5f5f5;
    }

    /* Admin Layout */
    .admin-main {
        padding: 30px;
        background: white;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        max-width: 1200px;
        margin: auto;
    }

    .admin-main h2 {
        font-size: 28px;
        color: #333;
    }

    .admin-main p {
        font-size: 16px;
        color: #666;
    }

    /* Users Table */
    .users-table-container {
        margin-top: 20px;
        overflow-x: auto;
    }

    .users-table {
        width: 100%;
        border-collapse: collapse;
        background: rgba(255, 255, 255, 0.15);
        border-radius: 10px;
        backdrop-filter: blur(10px);
        box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
    }

    .users-table thead {
        background: #ff6600;
        color: white;
    }

    .users-table th,
    .users-table td {
        padding: 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .users-table th {
        font-size: 16px;
        text-transform: uppercase;
    }

    .users-table tbody tr:hover {
        background: rgba(255, 165, 0, 0.1);
    }

    /* Profile Image */
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid white;
        transition: 0.3s;
    }

    .user-avatar:hover {
        transform: scale(1.1);
    }

    /* Seat Booking Status */
    .seat-status {
        padding: 6px 12px;
        border-radius: 5px;
        font-weight: bold;
        display: inline-block;
    }

    .booked {
        background: #28a745;
        color: white;
    }

    .not-booked {
        background: #dc3545;
        color: white;
    }

    /* Action Buttons */
    .edit-btn, .delete-btn {
        padding: 8px 12px;
        border-radius: 5px;
        text-decoration: none;
        font-size: 14px;
        transition: 0.3s;
    }

    .edit-btn {
        background: #00bfa6;
        color: white;
    }

    .delete-btn {
        background: #ff3b3b;
        color: white;
    }

    .edit-btn:hover {
        background: #008c76;
    }

    .delete-btn:hover {
        background: #c50000;
    }

    /* Responsive Design */
    @media screen and (max-width: 1024px) {
        .users-table-container {
            overflow-x: scroll;
        }
    }

    @media screen and (max-width: 600px) {
        .admin-main {
            padding: 20px;
        }

        .users-table th,
        .users-table td {
            font-size: 14px;
        }

        .edit-btn, .delete-btn {
            padding: 6px 10px;
            font-size: 12px;
        }
    }

    /* Days Left Styling */
    .days-left {
        padding: 6px 12px;
        border-radius: 5px;
        font-weight: bold;
        display: inline-block;
    }

    .active {
        background: #28a745;
        color: white;
    }

    .expired {
        background: #dc3545;
        color: white;
    }
</style>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2>👤 Manage Users</h2>
        <p>View, edit, or delete registered users along with their seat booking info.</p>

        <div class="users-table-container">
            <table class="users-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Profile</th>
                        <th>Seat No</th>
                        <th>Days Left</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = $users->fetch_assoc()) : ?>
                        <?php
                            // Calculate days left
                            $days_left = "Not Booked";
                            if ($user['expiry_date']) {
                                $today = new DateTime();
                                $expiry_date = new DateTime($user['expiry_date']);
                                $interval = $today->diff($expiry_date);
                                $days_left = ($expiry_date >= $today) ? $interval->days . " Days" : "Expired";
                            }
                        ?>
                        <tr>
                            <td><?= $user['id']; ?></td>
                            <td><?= $user['name']; ?></td>
                            <td><?= $user['email']; ?></td>
                            <td>
                                <img src="../uploads/<?= $user['profile_image'] ? $user['profile_image'] : 'default-avatar.png'; ?>" width="40" class="user-avatar">
                            </td>
                            <td>
                                <span class="seat-status <?= $user['seat_number'] ? 'booked' : 'not-booked'; ?>">
                                    <?= $user['seat_number'] ? $user['seat_number'] : 'Not Booked'; ?>
                                </span>
                            </td>
                            <td>
                                <span class="days-left <?= ($days_left === 'Expired') ? 'expired' : 'active'; ?>">
                                    <?= $days_left; ?>
                                </span>
                            </td>
                            <td>
                                <a href="edit_user.php?id=<?= $user['id']; ?>" class="edit-btn">✏️ Edit</a>
                                <a href="delete_user.php?id=<?= $user['id']; ?>" onclick="return confirm('Are you sure?')" class="delete-btn">❌ Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>