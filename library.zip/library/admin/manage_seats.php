<?php
include "config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Fetch all seats with booking details
$seats = $conn->query("
    SELECT s.*, b.user_id, b.start_date, b.expiry_date, u.name, u.email 
    FROM seats s 
    LEFT JOIN bookings b ON s.id = b.seat_id AND b.status = 'confirmed' 
    LEFT JOIN users u ON b.user_id = u.id 
    ORDER BY s.seat_number
");

// Fetch all users for dropdown
$users = $conn->query("SELECT id, name, email FROM users ORDER BY name");

// Add a New Seat
if (isset($_POST['add_seat'])) {
    $seat_number = $conn->real_escape_string($_POST['seat_number']);
    $conn->query("INSERT INTO seats (seat_number, status) VALUES ('$seat_number', 'available')");
    header("Location: manage_seats.php?success=Seat Added");
    exit();
}

// Book Seat for User
if (isset($_POST['book_seat'])) {
    $seat_id = $conn->real_escape_string($_POST['seat_id']);
    $user_id = (int)$_POST['user_id'];
    $plan = (int)$_POST['plan'];

    $seat = $conn->query("SELECT seat_number, status FROM seats WHERE id = $seat_id")->fetch_assoc();

    if ($seat['status'] === 'available') {
        $start_date = date('Y-m-d');
        $expiry_date = date('Y-m-d', strtotime('+30 days'));

        $stmt = $conn->prepare("INSERT INTO bookings (user_id, seat_id, amount_paid, start_date, expiry_date, status) VALUES (?, ?, ?, ?, ?, 'confirmed')");
        $stmt->bind_param("iiiss", $user_id, $seat_id, $plan, $start_date, $expiry_date);
        $stmt->execute();

        $conn->query("UPDATE seats SET status = 'booked' WHERE id = $seat_id");

        $message = "Admin has booked Seat {$seat['seat_number']} for you with a ₹$plan plan.";
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $message);
        $stmt->execute();

        header("Location: manage_seats.php?success=Seat Booked for User");
        exit();
    } else {
        header("Location: manage_seats.php?error=Seat is already booked");
        exit();
    }
}

// Update Seat Status or Change Booking
if (isset($_POST['update_seat'])) {
    $seat_id = $conn->real_escape_string($_POST['seat_id']);
    $new_status = $conn->real_escape_string($_POST['status']);
    
    $current_seat = $conn->query("SELECT status, seat_number FROM seats WHERE id = $seat_id")->fetch_assoc();
    
    if ($current_seat['status'] === 'booked' && $new_status === 'available') {
        $booking = $conn->query("SELECT user_id FROM bookings WHERE seat_id = $seat_id AND status = 'confirmed'")->fetch_assoc();
        if ($booking) {
            $user_id = $booking['user_id'];
            $conn->query("UPDATE bookings SET status = 'cancelled' WHERE seat_id = $seat_id AND status = 'confirmed'");
            $message = "Your booking for Seat {$current_seat['seat_number']} has been cancelled by the admin.";
            $conn->query("INSERT INTO notifications (user_id, message, created_at) VALUES ($user_id, '$message', NOW())");
        }
    } elseif ($new_status === 'booked' && $current_seat['status'] === 'available' && isset($_POST['user_id'])) {
        $user_id = (int)$_POST['user_id'];
        $plan = (int)$_POST['plan'];

        $start_date = date('Y-m-d');
        $expiry_date = date('Y-m-d', strtotime('+30 days'));

        $stmt = $conn->prepare("INSERT INTO bookings (user_id, seat_id, amount_paid, start_date, expiry_date, status) VALUES (?, ?, ?, ?, ?, 'confirmed')");
        $stmt->bind_param("iiiss", $user_id, $seat_id, $plan, $start_date, $expiry_date);
        $stmt->execute();

        $message = "Admin has booked Seat {$current_seat['seat_number']} for you with a ₹$plan plan.";
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $message);
        $stmt->execute();
    }

    $conn->query("UPDATE seats SET status = '$new_status' WHERE id = $seat_id");
    header("Location: manage_seats.php?success=Seat Updated");
    exit();
}

// Delete Seat
if (isset($_GET['delete_id'])) {
    $seat_id = $conn->real_escape_string($_GET['delete_id']);
    $seat_number = $conn->query("SELECT seat_number FROM seats WHERE id = $seat_id")->fetch_assoc()['seat_number'];
    $booking = $conn->query("SELECT user_id FROM bookings WHERE seat_id = $seat_id AND status = 'confirmed'")->fetch_assoc();
    
    if ($booking) {
        $user_id = $booking['user_id'];
        $conn->query("UPDATE bookings SET status = 'cancelled' WHERE seat_id = $seat_id AND status = 'confirmed'");
        $message = "Your booking for Seat $seat_number has been cancelled due to seat deletion by the admin.";
        $conn->query("INSERT INTO notifications (user_id, message, created_at) VALUES ($user_id, '$message', NOW())");
    }
    
    $conn->query("DELETE FROM seats WHERE id = $seat_id");
    header("Location: manage_seats.php?success=Seat Deleted");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Seats - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #2c3e50;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f4f6f9, #e9ecef);
            min-height: 100vh;
            padding: 20px;
        }

        .admin-main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            transition: margin-left 0.3s ease-in-out;
        }

        h2 {
            font-size: 28px;
            color: var(--text-color);
            text-align: center;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            color: #7f8c8d;
            text-align: center;
            margin-bottom: 25px;
        }

        .seat-form, .book-form {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            margin: 25px 0;
            padding: 20px;
            background: #fafafa;
            border-radius: 10px;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .seat-form input, .book-form select {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            background: white;
            min-width: 180px;
            transition: var(--transition);
        }

        .seat-form input:focus, .book-form select:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 5px rgba(255, 152, 0, 0.3);
        }

        .seat-form button, .book-form button {
            padding: 12px 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: var(--transition);
        }

        .seat-form button:hover, .book-form button:hover {
            background: #e68900;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(255, 152, 0, 0.3);
        }

        .seats-table-container {
            margin-top: 30px;
            overflow-x: auto;
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
        }

        .seats-table {
            width: 100%;
            border-collapse: collapse;
        }

        .seats-table thead {
            background: var(--primary-color);
            color: white;
        }

        .seats-table th, .seats-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .seats-table th {
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .seats-table tbody tr {
            transition: var(--transition);
        }

        .seats-table tbody tr:hover {
            background: rgba(255, 152, 0, 0.05);
            transform: scale(1.01);
        }

        .seat-status {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 500;
            display: inline-block;
            font-size: 12px;
        }

        .available { background: #28a745; color: white; }
        .booked { background: var(--danger-color); color: white; }

        .update-form {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-right: 10px;
        }

        .update-form select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            background: white;
            min-width: 120px;
            transition: var(--transition);
        }

        .update-form select:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        .update-form button {
            padding: 8px 15px;
            background: var(--secondary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
        }

        .update-form button:hover {
            background: #388e3c;
            transform: translateY(-2px);
        }

        .delete-btn {
            display: inline-block;
            padding: 8px 15px;
            background: var(--danger-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
        }

        .delete-btn:hover {
            background: #c0392b;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(231, 76, 60, 0.3);
        }

        .success, .error {
            text-align: center;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 14px;
            animation: fadeIn 0.5s ease-in-out;
        }

        .success { background: rgba(76, 175, 80, 0.1); color: var(--secondary-color); }
        .error { background: rgba(231, 76, 60, 0.1); color: var(--danger-color); }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .admin-main {
                margin-left: 0;
                padding: 20px;
            }

            .seat-form, .book-form {
                flex-direction: column;
                padding: 15px;
            }

            .seat-form input, .book-form select {
                width: 100%;
                margin-bottom: 10px;
            }

            .seats-table th, .seats-table td {
                font-size: 12px;
                padding: 12px;
            }

            .update-form {
                flex-direction: column;
                align-items: flex-start;
                margin-bottom: 10px;
            }

            .update-form select, .update-form button {
                width: 100%;
                margin-bottom: 10px;
            }

            .delete-btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2><i class="fa-solid fa-chair"></i> Manage Seats</h2>
        <p>Effortlessly manage seat availability and bookings</p>

        <?php if (isset($_GET['success'])): ?>
            <div class="success"><?= htmlspecialchars($_GET['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="error"><?= htmlspecialchars($_GET['error']); ?></div>
        <?php endif; ?>

        <!-- Add New Seat -->
        <div class="seat-form">
            <form action="manage_seats.php" method="POST">
                <input type="text" name="seat_number" placeholder="Enter Seat Number" required>
                <button type="submit" name="add_seat"><i class="fa-solid fa-plus"></i> Add Seat</button>
            </form>
        </div>

        <!-- Book Seat for User -->
        <div class="book-form">
            <form action="manage_seats.php" method="POST">
                <select name="seat_id" required>
                    <option value="">Select Seat</option>
                    <?php
                    $available_seats = $conn->query("SELECT id, seat_number FROM seats WHERE status = 'available'");
                    while ($seat = $available_seats->fetch_assoc()):
                    ?>
                        <option value="<?= $seat['id']; ?>"><?= $seat['seat_number']; ?></option>
                    <?php endwhile; ?>
                </select>
                <select name="user_id" required>
                    <option value="">Select User</option>
                    <?php
                    $users->data_seek(0);
                    while ($user = $users->fetch_assoc()):
                    ?>
                        <option value="<?= $user['id']; ?>">
                            <?= htmlspecialchars($user['name']) . " (LM ID: {$user['id']}, Email: {$user['email']})"; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <select name="plan" required>
                    
                    <option value="750">₹750/month</option>
                    <option value="850">₹850/month</option>
                </select>
                <button type="submit" name="book_seat"><i class="fa-solid fa-ticket"></i> Book Seat</button>
            </form>
        </div>

        <!-- List of Seats -->
        <div class="seats-table-container">
            <table class="seats-table">
                <thead>
                    <tr>
                        <th>Seat No</th>
                        <th>Status</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>LM ID</th>
                        <th>Start Date</th>
                        <th>Expiry Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($seat = $seats->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($seat['seat_number']); ?></td>
                            <td><span class="seat-status <?= $seat['status']; ?>"><?= ucfirst($seat['status']); ?></span></td>
                            <td><?= $seat['name'] ? htmlspecialchars($seat['name']) : '-'; ?></td>
                            <td><?= $seat['email'] ? htmlspecialchars($seat['email']) : '-'; ?></td>
                            <td><?= $seat['user_id'] ?? '-'; ?></td>
                            <td><?= $seat['start_date'] ? date("d-m-Y", strtotime($seat['start_date'])) : '-'; ?></td>
                            <td><?= $seat['expiry_date'] ? date("d-m-Y", strtotime($seat['expiry_date'])) : '-'; ?></td>
                            <td>
                                <form action="manage_seats.php" method="POST" class="update-form">
                                    <input type="hidden" name="seat_id" value="<?= $seat['id']; ?>">
                                    <select name="status">
                                        <option value="available" <?= $seat['status'] === 'available' ? 'selected' : ''; ?>>Available</option>
                                        <option value="booked" <?= $seat['status'] === 'booked' ? 'selected' : ''; ?>>Booked</option>
                                    </select>
                                    <?php if ($seat['status'] === 'available'): ?>
                                        <select name="user_id" required>
                                            <option value="">Select User</option>
                                            <?php
                                            $users->data_seek(0);
                                            while ($user = $users->fetch_assoc()):
                                            ?>
                                                <option value="<?= $user['id']; ?>">
                                                    <?= htmlspecialchars($user['name']) . " (LM ID: {$user['id']}, Email: {$user['email']})"; ?>
                                                </option>
                                            <?php endwhile; ?>
                                        </select>
                                        <select name="plan" required>
                                            
                                            <option value="750">₹750</option>
                                            <option value="850">₹850</option>
                                        </select>
                                    <?php endif; ?>
                                    <button type="submit" name="update_seat"><i class="fa-solid fa-sync"></i> Update</button>
                                </form>
                                <a href="manage_seats.php?delete_id=<?= $seat['id']; ?>" onclick="return confirm('Delete this seat? This will cancel any booking.')" class="delete-btn"><i class="fa-solid fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>