<?php
include "config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Fetch all users for dropdown
$users = $conn->query("SELECT id, name, email FROM users ORDER BY name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = (int)$_POST['user_id'];
    $purchase_date = date('Y-m-d');
    $expiry_date = date('Y-m-d', strtotime('+30 days'));

    // Check if user already has an active pass
    $existing_pass = $conn->query("SELECT id FROM library_passes WHERE user_id = $user_id AND status = 'active'")->fetch_assoc();
    if ($existing_pass) {
        $error = "This user already has an active library pass.";
    } else {
        // Insert new pass
        $stmt = $conn->prepare("INSERT INTO library_passes (user_id, purchase_date, expiry_date, status) VALUES (?, ?, ?, 'active')");
        $stmt->bind_param("iss", $user_id, $purchase_date, $expiry_date);
        if ($stmt->execute()) {
            // Notify user
            $user_name = $conn->query("SELECT name FROM users WHERE id = $user_id")->fetch_assoc()['name'];
            $message = "Admin has issued a Library Pass for you, valid until " . date("d-m-Y", strtotime($expiry_date)) . ".";
            $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("is", $user_id, $message);
            $stmt->execute();

            // Redirect with pass_issued flag
            header("Location: dashboard.php?success=Pass Issued Successfully&pass_issued=1");
            exit();
        } else {
            $error = "Error issuing pass: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issue Library Pass - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #2c3e50;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f4f6f9, #e9ecef);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .issue-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }

        h2 {
            font-size: 24px;
            color: var(--text-color);
            margin-bottom: 20px;
        }

        .success, .error {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            animation: fadeIn 0.5s ease-in-out;
        }

        .success { background: rgba(76, 175, 80, 0.1); color: var(--secondary-color); }
        .error { background: rgba(231, 76, 60, 0.1); color: var(--danger-color); }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        select {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            background: white;
            transition: var(--transition);
        }

        select:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 5px rgba(255, 152, 0, 0.3);
        }

        button {
            padding: 12px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: var(--transition);
        }

        button:hover {
            background: #e68900;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(255, 152, 0, 0.3);
        }

        .back-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
        }

        .back-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .issue-container {
                padding: 20px;
            }

            select, button {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="issue-container">
        <h2><i class="fa-solid fa-id-card"></i> Issue Library Pass</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?= $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <select name="user_id" required>
                <option value="">Select User</option>
                <?php while ($user = $users->fetch_assoc()): ?>
                    <option value="<?= $user['id']; ?>">
                        <?= htmlspecialchars($user['name']) . " (LM ID: {$user['id']}, Email: {$user['email']})"; ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <button type="submit"><i class="fa-solid fa-check"></i> Issue Pass</button>
        </form>
        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>
</body>
</html>