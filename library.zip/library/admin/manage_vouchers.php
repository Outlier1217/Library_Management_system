<?php
include "../config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch all vouchers
$vouchers = $conn->query("
    SELECT v.*, u.name AS user_name 
    FROM vouchers v 
    LEFT JOIN users u ON v.assigned_to = u.id 
    ORDER BY v.id DESC
");

// Handle voucher assignment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['assign_voucher'])) {
    $voucher_id = (int)$_POST['voucher_id'];
    $assigned_to = !empty($_POST['assigned_to']) ? (int)$_POST['assigned_to'] : NULL;

    $conn->begin_transaction();
    try {
        // Fetch current voucher details
        $voucher = $conn->query("SELECT assigned_to, credit_value, is_used FROM vouchers WHERE id = $voucher_id")->fetch_assoc();
        if (!$voucher) {
            throw new Exception("Voucher not found!");
        }
        $current_assigned_to = $voucher['assigned_to'];
        $credit_value = $voucher['credit_value'];
        $is_used = $voucher['is_used'];

        // Update assignment
        $stmt = $conn->prepare("UPDATE vouchers SET assigned_to = ?, is_used = ? WHERE id = ?");
        $is_used_new = $assigned_to && !$is_used ? 1 : $is_used; // Mark as used if newly assigned
        $stmt->bind_param("iii", $assigned_to, $is_used_new, $voucher_id);
        $stmt->execute();

        // If newly assigned and not previously used, add credits and log history
        if ($assigned_to && !$is_used) {
            $stmt = $conn->prepare("UPDATE users SET credits = credits + ? WHERE id = ?");
            $stmt->bind_param("ii", $credit_value, $assigned_to);
            $stmt->execute();

            // Log to credit history
            $stmt = $conn->prepare("INSERT INTO credit_history (user_id, amount, source, description) VALUES (?, ?, 'admin', ?)");
            $description = "Voucher assigned by admin: " . $voucher['code'];
            $stmt->bind_param("iis", $assigned_to, $credit_value, $description);
            $stmt->execute();
        }

        // If unassigned and credits were previously added, optionally remove them (commented out for now)
        /*
        if (!$assigned_to && $current_assigned_to && $is_used) {
            $stmt = $conn->prepare("UPDATE users SET credits = credits - ? WHERE id = ?");
            $stmt->bind_param("ii", $credit_value, $current_assigned_to);
            $stmt->execute();

            // Optionally log credit removal (if desired)
            $stmt = $conn->prepare("INSERT INTO credit_history (user_id, amount, source, description) VALUES (?, ?, 'admin', 'Voucher unassigned, credits removed')");
            $stmt->bind_param("ii", $current_assigned_to, $credit_value);
            $stmt->execute();
        }
        */

        $conn->commit();
        echo "<script>alert('Voucher assigned successfully!" . ($assigned_to && !$is_used ? " Credits added to user." : "") . "'); window.location.href='manage_vouchers.php';</script>";
    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>alert('Error assigning voucher: " . addslashes($e->getMessage()) . "');</script>";
    }
}

// Fetch all users for assignment dropdown
$users = $conn->query("SELECT id, name FROM users ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Vouchers</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .vouchers-container {
            background: #fff;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #ff6600;
            color: white;
        }
        tr:hover {
            background: #f9f9f9;
        }
        select {
            padding: 5px;
            border-radius: 5px;
        }
        button {
            padding: 5px 10px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #45a049;
        }
        .status-used {
            color: #e74c3c;
            font-weight: bold;
        }
        .status-unused {
            color: #2ecc71;
            font-weight: bold;
        }
        .back-link {
            display: inline-block;
            padding: 10px 10px;
            background: #ff6600;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
        }
        .back-link:hover {
            background: #cc5200;
        }
    </style>
</head>
<body>
    <div class="vouchers-container">
        <h2>Manage Vouchers</h2>
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Credits</th>
                    <th>Assigned To</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($voucher = $vouchers->fetch_assoc()): ?>
                <tr>
                    <td><?= $voucher['id']; ?></td>
                    <td><?= htmlspecialchars($voucher['code']); ?></td>
                    <td><?= $voucher['credit_value']; ?></td>
                    <td><?= $voucher['user_name'] ? htmlspecialchars($voucher['user_name']) : 'Unassigned'; ?></td>
                    <td>
                        <span class="<?= $voucher['is_used'] ? 'status-used' : 'status-unused'; ?>">
                            <?= $voucher['is_used'] ? 'Used' : 'Unused'; ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="voucher_id" value="<?= $voucher['id']; ?>">
                            <select name="assigned_to">
                                <option value="">-- Unassign --</option>
                                <?php
                                $users->data_seek(0);
                                while ($user = $users->fetch_assoc()): ?>
                                    <option value="<?= $user['id']; ?>" <?= $voucher['assigned_to'] == $user['id'] ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($user['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <button type="submit" name="assign_voucher">Assign</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        
    </div>
</body>
</html>