<?php
include "config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Fetch statistics
$total_users = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
$total_seats = $conn->query("SELECT COUNT(*) AS total FROM seats")->fetch_assoc()['total'];
$total_bookings = $conn->query("SELECT COUNT(*) AS total FROM bookings WHERE status = 'confirmed'")->fetch_assoc()['total'];
$total_passes = $conn->query("SELECT COUNT(*) AS total FROM library_passes WHERE status = 'active'")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #2c3e50;
            --shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f4f6f9, #e9ecef);
            min-height: 100vh;
            padding: 20px;
        }

        .admin-main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: var(--shadow);
            transition: margin-left 0.3s ease-in-out;
        }

        h2 {
            font-size: 28px;
            color: var(--text-color);
            text-align: center;
            margin-bottom: 10px;
        }

        p {
            font-size: 16px;
            color: #7f8c8d;
            text-align: center;
            margin-bottom: 25px;
        }

        .admin-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-box {
            background: #fafafa;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        .stat-box h3 {
            font-size: 18px;
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .stat-box p {
            font-size: 24px;
            font-weight: 600;
            color: var(--primary-color);
            margin: 0;
        }

        .admin-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .action-card {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        .action-card h3 {
            font-size: 18px;
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .action-card p {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 15px;
        }

        .action-card a {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: var(--transition);
        }

        .action-card a:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        /* Popup Styles */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            z-index: 1000;
            text-align: center;
            animation: fadeInPopup 0.5s ease-in-out;
        }

        .popup h3 {
            font-size: 20px;
            color: var(--secondary-color);
            margin-bottom: 15px;
        }

        .popup p {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 20px;
        }

        .popup button {
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
        }

        .popup button:hover {
            background: #e68900;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        @keyframes fadeInPopup {
            from { opacity: 0; transform: translate(-50%, -60%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }

        @media (max-width: 768px) {
            .admin-main {
                padding: 20px;
                margin-left: 0;
            }

            .stat-box, .action-card {
                padding: 15px;
            }

            .stat-box p {
                font-size: 20px;
            }

            .popup {
                width: 90%;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2><i class="fa-solid fa-tachometer-alt"></i> Welcome, Admin!</h2>
        <p>Manage users, bookings, seats, and passes efficiently</p>

        <!-- Admin Stats -->
        <div class="admin-stats">
            <div class="stat-box">
                <h3><i class="fa-solid fa-users"></i> Users</h3>
                <p><?= $total_users; ?></p>
            </div>
            <div class="stat-box">
                <h3><i class="fa-solid fa-chair"></i> Seats</h3>
                <p><?= $total_seats; ?></p>
            </div>
            <div class="stat-box">
                <h3><i class="fa-solid fa-ticket-alt"></i> Bookings</h3>
                <p><?= $total_bookings; ?></p>
            </div>
            <div class="stat-box">
                <h3><i class="fa-solid fa-id-card"></i> Passes</h3>
                <p><?= $total_passes; ?></p>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="admin-actions">
            <div class="action-card">
                <h3><i class="fa-solid fa-users-cog"></i> Manage Users</h3>
                <p>View and manage all registered users.</p>
                <a href="manage_users.php">Manage Users</a>
            </div>
            <div class="action-card">
                <h3><i class="fa-solid fa-chair"></i> Manage Seats</h3>
                <p>Add, remove, or update seat status.</p>
                <a href="manage_seats.php">Manage Seats</a>
            </div>
            <div class="action-card">
                <h3><i class="fa-solid fa-bell"></i> Send Notifications</h3>
                <p>Send updates and alerts to users.</p>
                <a href="notifications.php">Send Now</a>
            </div>
            <div class="action-card">
                <h3><i class="fa-solid fa-envelope"></i> All Messages</h3>
                <p>View all sent messages.</p>
                <a href="manage_messages.php">All Messages</a>
            </div>
        </div>

        <!-- Voucher, Credits, and Pass Actions -->
        <div class="admin-actions">
            <div class="action-card">
                <h3><i class="fa-solid fa-ticket-alt"></i> Manage Vouchers</h3>
                <p>Create and assign vouchers to users.</p>
                <a href="manage_vouchers.php">Manage Vouchers</a>
            </div>
            <div class="action-card">
                <h3><i class="fa-solid fa-plus-circle"></i> Add Vouchers</h3>
                <p>Create new vouchers for users.</p>
                <a href="create_voucher.php">Create Voucher</a>
            </div>
            <div class="action-card">
                <h3><i class="fa-solid fa-coins"></i> Add Credits</h3>
                <p>Add credits to user accounts.</p>
                <a href="add_credits.php">Add Credits</a>
            </div>
            <div class="action-card">
                <h3><i class="fa-solid fa-id-card"></i> Issue Pass</h3>
                <p>Issue library passes to users.</p>
                <a href="issue_pass.php">Issue Pass</a>
            </div>
        </div>
    </main>

    <!-- Popup for Pass Issuance -->
    <div class="overlay" id="popupOverlay"></div>
    <div class="popup" id="passPopup">
        <h3><i class="fa-solid fa-check-circle"></i> Pass Issued!</h3>
        <p>The library pass has been successfully issued to the user.</p>
        <button onclick="closePopup()">Close</button>
    </div>

    <script>
        // Check if pass_issued flag is present in URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('pass_issued') === '1') {
            document.getElementById('passPopup').style.display = 'block';
            document.getElementById('popupOverlay').style.display = 'block';
        }

        function closePopup() {
            document.getElementById('passPopup').style.display = 'none';
            document.getElementById('popupOverlay').style.display = 'none';
            // Remove pass_issued from URL without reloading
            window.history.replaceState({}, document.title, 'dashboard.php' + (urlParams.get('success') ? '?success=' + urlParams.get('success') : ''));
        }
    </script>
</body>
</html>