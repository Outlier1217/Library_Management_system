<?php
include "config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Fetch contact messages
$messages_result = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");

// Fetch suggestions with user details
$suggestions_result = $conn->query("
    SELECT s.*, u.name, u.id AS lm_id 
    FROM suggestions s 
    JOIN users u ON s.user_id = u.id 
    ORDER BY s.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Messages & Suggestions</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
        }

        .admin-main {
            padding: 20px;
            margin-left: 250px;
            transition: margin-left 0.3s ease-in-out;
        }

        h2 {
            color: #2c3e50;
            text-align: center;
            font-size: 28px;
            margin-bottom: 10px;
        }

        p {
            text-align: center;
            color: #7f8c8d;
            margin-bottom: 30px;
        }

        .messages-container, .suggestions-container {
            max-width: 90%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background: #2c3e50;
            color: white;
        }

        tr:hover {
            background: #ecf0f1;
        }

        .btn {
            display: inline-block;
            padding: 8px 12px;
            margin: 5px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn-view {
            background: #3498db;
        }

        .btn-view:hover {
            background: #2980b9;
        }

        .no-messages, .no-suggestions {
            text-align: center;
            color: #7f8c8d;
            font-size: 18px;
            padding: 20px;
        }

        @media screen and (max-width: 768px) {
            .admin-main {
                margin-left: 0;
                padding: 10px;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .messages-container, .suggestions-container {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2><i class="fa-solid fa-envelope"></i> Contact Messages</h2>
        <p>View all messages sent by users.</p>

        <div class="messages-container">
            <?php if ($messages_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $messages_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id']; ?></td>
                                <td><?= htmlspecialchars($row['name']); ?></td>
                                <td><?= htmlspecialchars($row['email']); ?></td>
                                <td><?= htmlspecialchars($row['message']); ?></td>
                                <td><?= date("d-m-Y H:i", strtotime($row['created_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-messages">No messages found.</p>
            <?php endif; ?>
        </div>

        <h2><i class="fa-solid fa-comment"></i> User Suggestions</h2>
        <p>View all suggestions submitted by users.</p>

        <div class="suggestions-container">
            <?php if ($suggestions_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User Name</th>
                            <th>LM ID</th>
                            <th>Suggestion</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $suggestions_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id']; ?></td>
                                <td><?= htmlspecialchars($row['name']); ?></td>
                                <td><?= $row['lm_id']; ?></td>
                                <td><?= htmlspecialchars($row['suggestion']); ?></td>
                                <td><?= date("d-m-Y H:i", strtotime($row['created_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-suggestions">No suggestions found.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>