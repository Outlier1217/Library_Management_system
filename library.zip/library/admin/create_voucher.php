<?php
include "../config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $voucher_code = !empty($_POST['voucher_code']) ? strtoupper($_POST['voucher_code']) : strtoupper("LM" . substr(uniqid(), -6) . $_POST['credit_value']);
    $credit_value = (int)$_POST['credit_value'];
    $assigned_to = !empty($_POST['assigned_to']) ? (int)$_POST['assigned_to'] : NULL;

    if ($credit_value <= 0) {
        echo "<script>alert('Invalid credit value! Must be greater than 0.');</script>";
    } else {
        $conn->begin_transaction();
        try {
            // Check if voucher code already exists
            $check_stmt = $conn->prepare("SELECT id FROM vouchers WHERE code = ?");
            $check_stmt->bind_param("s", $voucher_code);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                throw new Exception("Voucher code '$voucher_code' already exists!");
            }

            // Insert voucher
            $stmt = $conn->prepare("INSERT INTO vouchers (code, credit_value, is_used, assigned_to) VALUES (?, ?, ?, ?)");
            $is_used = $assigned_to ? 1 : 0; // Mark as used if assigned
            $stmt->bind_param("siii", $voucher_code, $credit_value, $is_used, $assigned_to);
            $stmt->execute();

            // If assigned to a user, auto-add credits and log history
            if ($assigned_to) {
                $stmt = $conn->prepare("UPDATE users SET credits = credits + ? WHERE id = ?");
                $stmt->bind_param("ii", $credit_value, $assigned_to);
                $stmt->execute();

                // Log credit history
                $stmt = $conn->prepare("INSERT INTO credit_history (user_id, amount, source, description) VALUES (?, ?, 'admin', 'Voucher assigned by admin')");
                $stmt->bind_param("ii", $assigned_to, $credit_value);
                $stmt->execute();
            }

            $conn->commit();
            echo "<script>alert('Voucher Created! Code: $voucher_code" . ($assigned_to ? " and credits added to user" : "") . "'); window.location.href='create_voucher.php';</script>";
        } catch (Exception $e) {
            $conn->rollback();
            echo "<script>alert('Error creating voucher: " . addslashes($e->getMessage()) . "');</script>";
        }
    }
}

// Fetch all users for the dropdown
$users = $conn->query("SELECT id, name FROM users ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Voucher</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .voucher-container {
            background: #fff;
            padding: 30px;
            width: 400px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: bold;
            color: #555;
            text-align: left;
        }
        input[type="text"], input[type="number"], select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
        }
        button {
            padding: 12px;
            background: #ff6600;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #cc5200;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #666;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
        }
        .back-link:hover {
            background: #444;
        }
    </style>
</head>
<body>
    <div class="voucher-container">
        <h2>Create Voucher</h2>
        <form method="post">
            <label for="voucher_code">Voucher Code (optional):</label>
            <input type="text" name="voucher_code" id="voucher_code" placeholder="Leave blank for auto-generated">

            <label for="credit_value">Credit Value:</label>
            <input type="number" name="credit_value" id="credit_value" required min="1" placeholder="Enter credit amount">

            <label for="assigned_to">Assign to User (optional):</label>
            <select name="assigned_to" id="assigned_to">
                <option value="">-- Select User (Optional) --</option>
                <?php while ($user = $users->fetch_assoc()): ?>
                    <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['name']); ?></option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Create Voucher</button>
        </form>
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>