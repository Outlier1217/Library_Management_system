<?php

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../index.php");
    exit();
}
?>
<header class="admin-header">
    <h1>Admin Panel</h1>
    <a href="logout.php" class="logout-btn">Logout</a>
</header>
