<nav class="admin-sidebar">
    <ul>
        <li><a href="dashboard.php">🏠 Dashboard</a></li>
        <li><a href="manage_users.php">👤 Manage Users</a></li>
        <li><a href="manage_seats.php">💺 Manage Seats</a></li>
        <li><a href="manage_bookings.php">📅 Manage Bookings</a></li>
        <li><a href="view_users.php">👤 View Users Add Info</a></li>
        <li><a href="notifications.php">📢 Send Notifications</a></li>
        <li><a href="admin_register.php">➕ Add Admin</a></li>
        <li><a href="logout.php">🚪 Logout</a></li>
    </ul>
</nav>
