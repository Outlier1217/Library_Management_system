<?php
include "config.php";


// Check if logged-in admin is a Super Admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_role'] !== 'superadmin') {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role']; // 'admin' or 'superadmin'

    // Check if admin already exists
    $check = $conn->query("SELECT * FROM admin WHERE email = '$email'");
    if ($check->num_rows > 0) {
        $error_message = "Admin with this email already exists!";
    } else {
        // Insert new admin
        $stmt = $conn->prepare("INSERT INTO admin (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);
        if ($stmt->execute()) {
            $success_message = "New admin registered successfully!";
        } else {
            $error_message = "Error creating admin!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Admin</title>
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
    <div class="admin-container">
        <h2>Register New Admin</h2>
        <?php if (isset($error_message)) : ?>
            <p class="error-msg"><?= $error_message; ?></p>
        <?php endif; ?>
        <?php if (isset($success_message)) : ?>
            <p class="success-msg"><?= $success_message; ?></p>
        <?php endif; ?>
        <form action="admin_register.php" method="POST">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role" required>
                <option value="admin">Admin</option>
                <option value="superadmin">Super Admin</option>
            </select>
            <button type="submit">Register Admin</button>
        </form>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
