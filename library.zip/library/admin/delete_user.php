<?php
include "config.php";


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Get the user's booked seat (if any)
    $booking = $conn->query("SELECT seat_id FROM bookings WHERE user_id = $user_id")->fetch_assoc();

    if ($booking) {
        $seat_id = $booking['seat_id'];

        // Delete the user's booking
        $conn->query("DELETE FROM bookings WHERE user_id = $user_id");

        // Mark the seat as available
        $conn->query("UPDATE seats SET status='available' WHERE id = $seat_id");
    }

    // Delete the user
    $conn->query("DELETE FROM users WHERE id = $user_id");

    header("Location: manage_users.php?success=User Deleted & Seat Freed");
}
?>
