<?php
include "config.php";


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

$users = $conn->query("SELECT * FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users</title>
    <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2>All Users</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>DOB</th>
                <th>Profile</th>
                <th>ID Proof</th>
            </tr>
            <?php while ($user = $users->fetch_assoc()) : ?>
                <tr>
                    <td><?= $user['id']; ?></td>
                    <td><?= $user['name']; ?></td>
                    <td><?= $user['email']; ?></td>
                    <td><?= $user['phone']; ?></td>
                    <td><?= $user['home_address']; ?></td>
                    <td><?= $user['dob']; ?></td>
                    <td>
                        <?php if ($user['profile_photo']) : ?>
                            <img src="../<?= $user['profile_photo']; ?>" width="50">
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($user['id_proof']) : ?>
                            <a href="../<?= $user['id_proof']; ?>" target="_blank">View</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </main>
</body>
</html>
