<?php
include "../config.php";

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = (int)$_POST['user_id'];
    $credits = (int)$_POST['credits'];

    if ($credits <= 0) {
        echo "<script>alert('Invalid credit amount! Must be greater than 0.');</script>";
    } else {
        $conn->begin_transaction();
        try {
            // Update user credits
            $stmt = $conn->prepare("UPDATE users SET credits = credits + ? WHERE id = ?");
            $stmt->bind_param("ii", $credits, $user_id);
            $stmt->execute();

            // Log credit history
            $stmt = $conn->prepare("INSERT INTO credit_history (user_id, amount, source, description) VALUES (?, ?, 'admin', 'Credits added by admin')");
            $stmt->bind_param("ii", $user_id, $credits);
            $stmt->execute();

            $conn->commit();
            echo "<script>alert('Credits added successfully!'); window.location.href='add_credits.php';</script>";
        } catch (Exception $e) {
            $conn->rollback();
            echo "<script>alert('Error adding credits: " . addslashes($e->getMessage()) . "');</script>";
        }
    }
}

$users = $conn->query("SELECT id, name, credits FROM users ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Credits</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .credits-container {
            background: #fff;
            padding: 30px;
            width: 400px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        label {
            font-weight: bold;
            color: #555;
            text-align: left;
        }
        select, input[type="number"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
        }
        button {
            padding: 12px;
            background: #ff6600;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #cc5200;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #666;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
        }
        .back-link:hover {
            background: #444;
        }
    </style>
</head>
<body>
    <div class="credits-container">
        <h2>Add Credits to User</h2>
        <form method="post">
            <label for="user_id">Select User:</label>
            <select name="user_id" id="user_id" required>
                <option value="">-- Select User --</option>
                <?php while ($user = $users->fetch_assoc()): ?>
                    <option value="<?= $user['id']; ?>"><?= htmlspecialchars($user['name']); ?> (<?= $user['credits']; ?> LM)</option>
                <?php endwhile; ?>
            </select>

            <label for="credits">Credits to Add:</label>
            <input type="number" name="credits" id="credits" required min="1" placeholder="Enter credit amount">

            <button type="submit">Add Credits</button>
        </form>
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>