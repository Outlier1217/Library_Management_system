<?php
include "config.php";


if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// Fetch all users for sending individual notifications
$users = $conn->query("SELECT id, name FROM users");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = $_POST['message'];
    $user_id = $_POST['user_id']; // User ID (if sending to an individual)

    if ($user_id == "all") {
        // Send to all users (NULL means global notification)
        $conn->query("INSERT INTO notifications (user_id, message, created_at) VALUES (NULL, '$message', NOW())");
    } else {
        // Send to specific user
        $conn->query("INSERT INTO notifications (user_id, message, created_at) VALUES ('$user_id', '$message', NOW())");
    }

    header("Location: notifications.php?success=Notification Sent");
}

// Fetch notifications (Both global and individual)
$notifications = $conn->query("
    SELECT n.*, u.name AS recipient_name 
    FROM notifications n 
    LEFT JOIN users u ON n.user_id = u.id 
    ORDER BY created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notifications</title>
    <link rel="stylesheet" href="assets/css/admin.css">
</head>

<style>

    /* Notification Form */
.notification-form {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}

.notification-form textarea {
    width: 100%;
    height: 80px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
    resize: none;
}

.notification-form select {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.notification-form button {
    margin-top: 10px;
    padding: 10px;
    background: orange;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.notification-form button:hover {
    background: darkorange;
}

/* Notification List */
.notification-list {
    margin-top: 20px;
    list-style: none;
    padding: 0;
}

.notification-list li {
    background: white;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}

.notification-list .notif-time {
    color: grey;
    font-size: 12px;
    display: block;
    margin-top: 5px;
}

</style>
<body>
    <?php include "includes/header.php"; ?>
    <?php include "includes/sidebar.php"; ?>

    <main class="admin-main">
        <h2>📢 Send Notification</h2>

        <!-- Notification Form -->
        <form action="notifications.php" method="POST" class="notification-form">
            <textarea name="message" placeholder="Write your notification..." required></textarea>

            <!-- Select User -->
            <label>Select Recipient:</label>
            <select name="user_id">
                <option value="all">All Users</option>
                <?php while ($user = $users->fetch_assoc()) : ?>
                    <option value="<?= $user['id']; ?>"><?= $user['name']; ?></option>
                <?php endwhile; ?>
            </select>

            <button type="submit">Send</button>
        </form>

        <!-- Previous Notifications -->
        <h3>📜 Previous Notifications</h3>
        <ul class="notification-list">
            <?php while ($notif = $notifications->fetch_assoc()) : ?>
                <li>
                    <strong><?= $notif['recipient_name'] ? $notif['recipient_name'] : "All Users"; ?></strong> - 
                    <?= $notif['message']; ?> 
                    <span class="notif-time">(<?= date("d-m-Y H:i A", strtotime($notif['created_at'])); ?>)</span>
                </li>
            <?php endwhile; ?>
        </ul>
    </main>
</body>
</html>
