<?php
include "config.php"; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $message = mysqli_real_escape_string($conn, $_POST["message"]);

    // Insert data into the database
    $query = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";

    if (mysqli_query($conn, $query)) {
        // Show success popup and redirect to index.php
        echo "<script>
                alert('Message sent successfully!');
                window.location.href = 'index.php';
              </script>";
        exit();
    } else {
        // Show error popup and redirect back to contact.php
        echo "<script>
                alert('Error! Please try again.');
                window.location.href = 'contact.php';
              </script>";
        exit();
    }
} else {
    // Redirect if accessed directly
    header("Location: contact.php");
    exit();
}
?>
