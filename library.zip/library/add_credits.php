<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details with prepared statement
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$current_credits = $user['credits'];

// Handle voucher submission
$voucher_message = '';
if (isset($_POST['apply_voucher'])) {
    $voucher_code = trim($_POST['voucher_code']);
    
    $stmt = $conn->prepare("SELECT * FROM vouchers WHERE code = ? AND is_used = 0");
    $stmt->bind_param("s", $voucher_code);
    $stmt->execute();
    $voucher = $stmt->get_result()->fetch_assoc();
    
    if ($voucher) {
        if ($voucher['assigned_to'] !== null && $voucher['assigned_to'] != $user_id) {
            $voucher_message = "<p class='error'>This voucher is not assigned to you.</p>";
        } else {
            $credit_value = $voucher['credit_value'];
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("UPDATE users SET credits = credits + ? WHERE id = ?");
                $stmt->bind_param("ii", $credit_value, $user_id);
                $stmt->execute();

                $stmt = $conn->prepare("INSERT INTO credit_history (user_id, amount, source, description) VALUES (?, ?, ?, ?)");
                $source = $user['name'];
                $description = "Voucher applied: $voucher_code";
                $stmt->bind_param("iiss", $user_id, $credit_value, $source, $description);
                $stmt->execute();

                $stmt = $conn->prepare("UPDATE vouchers SET is_used = 1 WHERE id = ?");
                $stmt->bind_param("i", $voucher['id']);
                $stmt->execute();

                $conn->commit();
                $voucher_message = "<p class='success'>Voucher applied successfully! You received $credit_value LM Credits.</p>";
                $current_credits += $credit_value;
            } catch (Exception $e) {
                $conn->rollback();
                $voucher_message = "<p class='error'>Error applying voucher: " . $e->getMessage() . "</p>";
            }
        }
    } else {
        $voucher_message = "<p class='error'>Invalid or already used voucher.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Credits - LM Library</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        :root {
            --primary-color: #ff9800;
            --secondary-color: #4CAF50;
            --danger-color: #e74c3c;
            --text-color: #fff;
            --shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            color: var(--text-color);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .credit-container {
            background: rgba(255, 255, 255, 0.2);
            padding: 30px;
            border-radius: 12px;
            backdrop-filter: blur(12px);
            box-shadow: var(--shadow);
            width: 90%;
            max-width: 400px;
            text-align: center;
        }

        h2 {
            font-size: 26px;
            margin-bottom: 15px;
        }

        .balance {
            font-size: 18px;
            background: rgba(255, 255, 255, 0.15);
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .credit-options {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 20px;
        }

        .credit-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: var(--transition);
        }

        .credit-btn:hover {
            background: #e68900;
            transform: scale(1.05);
        }

        .custom-amount {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            font-size: 16px;
            text-align: center;
            margin-bottom: 20px;
            background: rgba(255, 255, 255, 0.9);
            color: #333;
        }

        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 20px;
        }

        .pay-btn {
            background: var(--primary-color);
            padding: 12px;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: var(--transition);
        }

        .pay-btn:hover {
            background: #e68900;
            transform: scale(1.05);
        }

        .voucher-section {
            margin-bottom: 20px;
        }

        .voucher-input {
            width: 70%;
            padding: 10px;
            border-radius: 8px 0 0 8px;
            border: none;
            font-size: 14px;
            background: rgba(255, 255, 255, 0.9);
            color: #333;
        }

        .apply-voucher-btn {
            background: var(--secondary-color);
            padding: 10px 15px;
            border: none;
            color: white;
            font-size: 14px;
            border-radius: 0 8px 8px 0;
            cursor: pointer;
            transition: var(--transition);
        }

        .apply-voucher-btn:hover {
            background: #388e3c;
        }

        .voucher-message .success {
            color: #4CAF50;
        }

        .voucher-message .error {
            color: var(--danger-color);
        }

        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: var(--transition);
        }

        .back-btn:hover {
            background: #e68900;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .credit-container {
                padding: 20px;
            }

            .voucher-input {
                width: 60%;
            }
        }
    </style>
</head>
<body>
    <div class="credit-container">
        <h2><i class="fa-solid fa-coins"></i> Add Credits</h2>
        <div class="balance">Current Balance: <strong><?= $current_credits; ?> LM</strong></div>

        <form id="credit-form">
            <div class="credit-options">
                <button type="button" class="credit-btn" onclick="setAmount(100)">+100 LM</button>
                <button type="button" class="credit-btn" onclick="setAmount(250)">+250 LM</button>
                <button type="button" class="credit-btn" onclick="setAmount(500)">+500 LM</button>
            </div>
            <input type="number" id="custom-amount" class="custom-amount" placeholder="Enter Custom Amount" min="1">
        </form>

        <div class="payment-options">
            <button class="pay-btn" onclick="payWithPaytm()">Pay with Paytm</button>
            <button class="pay-btn" onclick="payWithRazorpay()">Pay with Razorpay</button>
        </div>

        <div class="voucher-section">
            <form method="POST" action="">
                <input type="text" name="voucher_code" class="voucher-input" placeholder="Enter Voucher Code" required>
                <button type="submit" name="apply_voucher" class="apply-voucher-btn">Apply</button>
            </form>
            <div class="voucher-message"><?= $voucher_message; ?></div>
        </div>

        <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
    </div>

    <script>
        function setAmount(amount) {
            document.getElementById('custom-amount').value = amount;
        }

        function payWithPaytm() {
            let amount = document.getElementById('custom-amount').value;
            if (!amount || amount <= 0) {
                alert("Please enter a valid amount.");
                return;
            }
            window.location.href = "paytm_payment.php?amount=" + amount;
        }

        
    </script>
</body>
</html>